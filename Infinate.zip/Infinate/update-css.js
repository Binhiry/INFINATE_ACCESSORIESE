cssconst fs = require('fs');
const path = require('path');

const filesToUpdate = [
    'inspiration.html',
    'membership.html'
];

filesToUpdate.forEach(file => {
    const filePath = path.join(__dirname, file);
    
    try {
        let content = fs.readFileSync(filePath, 'utf8');
        
        // Replace shared.css with complete-styles.css
        if (content.includes('shared.css')) {
            content = content.replace('shared.css', 'complete-styles.css');
            fs.writeFileSync(filePath, content, 'utf8');
            console.log(`Updated ${file} successfully`);
        } else {
            console.log(`Skipped ${file} - already updated or no shared.css found`);
        }
    } catch (error) {
        console.error(`Error updating ${file}:`, error.message);
    }
});

console.log('CSS update process completed.');

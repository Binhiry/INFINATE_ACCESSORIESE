<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class Database {
    private $host = 'localhost';
    private $port = '3002';
    private $dbname = 'INFINATE';
    private $username = 'root';
    private $password = '1234';
    private $conn;

    public function connect() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};port={$this->port};dbname={$this->dbname};charset=utf8mb4", 
                                 $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
            return null;
        }
    }
}

class ProductManager {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
    }

    public function getProducts() {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category = c.name 
                ORDER BY p.created_at DESC
            ");
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format products for frontend
            foreach ($products as &$product) {
                $product['stock_status'] = $this->getStockStatus($product['stock']);
                $product['formatted_price'] = '¥ ' . number_format($product['price'], 2);
            }
            
            echo json_encode(['success' => true, 'data' => $products]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch products: ' . $e->getMessage()]);
        }
    }

    public function addProduct($data) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO products (name, style, category, price, original_price, stock, 
                                    description, sizes, colors, brand, status, tags, 
                                    seo_keywords, seo_description, image_url)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $data['name'],
                $data['style'],
                $data['category'],
                $data['price'],
                $data['original_price'] ?? null,
                $data['stock'] ?? 0,
                $data['description'] ?? '',
                $data['sizes'] ?? '',
                $data['colors'] ?? '',
                $data['brand'] ?? '',
                $data['status'] ?? 'active',
                $data['tags'] ?? '',
                $data['seo_keywords'] ?? '',
                $data['seo_description'] ?? '',
                $data['image_url'] ?? ''
            ]);
            
            $productId = $this->db->lastInsertId();
            echo json_encode(['success' => true, 'message' => 'Product added successfully', 'id' => $productId]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to add product: ' . $e->getMessage()]);
        }
    }

    public function updateProduct($id, $data) {
        try {
            $stmt = $this->db->prepare("
                UPDATE products SET name=?, style=?, category=?, price=?, original_price=?, 
                                   stock=?, description=?, sizes=?, colors=?, brand=?, 
                                   status=?, tags=?, seo_keywords=?, seo_description=?, 
                                   image_url=?, updated_at=CURRENT_TIMESTAMP
                WHERE id=?
            ");
            
            $stmt->execute([
                $data['name'],
                $data['style'],
                $data['category'],
                $data['price'],
                $data['original_price'] ?? null,
                $data['stock'] ?? 0,
                $data['description'] ?? '',
                $data['sizes'] ?? '',
                $data['colors'] ?? '',
                $data['brand'] ?? '',
                $data['status'] ?? 'active',
                $data['tags'] ?? '',
                $data['seo_keywords'] ?? '',
                $data['seo_description'] ?? '',
                $data['image_url'] ?? '',
                $id
            ]);
            
            echo json_encode(['success' => true, 'message' => 'Product updated successfully']);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to update product: ' . $e->getMessage()]);
        }
    }

    public function deleteProduct($id) {
        try {
            $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode(['success' => true, 'message' => 'Product deleted successfully']);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to delete product: ' . $e->getMessage()]);
        }
    }

    public function updateStock($id, $stock) {
        try {
            $stmt = $this->db->prepare("UPDATE products SET stock = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
            $stmt->execute([$stock, $id]);
            
            echo json_encode(['success' => true, 'message' => 'Stock updated successfully']);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to update stock: ' . $e->getMessage()]);
        }
    }

    private function getStockStatus($stock) {
        if ($stock == 0) return 'out';
        if ($stock < 5) return 'low';
        if ($stock < 20) return 'warning';
        return 'ok';
    }

    public function getCategories() {
        try {
            $stmt = $this->db->prepare("SELECT * FROM categories WHERE status = 'active' ORDER BY sort_order, name");
            $stmt->execute();
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'data' => $categories]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch categories: ' . $e->getMessage()]);
        }
    }

    public function getInventoryStats() {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    SUM(CASE WHEN stock > 20 THEN 1 ELSE 0 END) as sufficient,
                    SUM(CASE WHEN stock BETWEEN 5 AND 20 THEN 1 ELSE 0 END) as warning,
                    SUM(CASE WHEN stock BETWEEN 1 AND 4 THEN 1 ELSE 0 END) as low,
                    SUM(CASE WHEN stock = 0 THEN 1 ELSE 0 END) as out
                FROM products
            ");
            $stmt->execute();
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'data' => $stats]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch inventory stats: ' . $e->getMessage()]);
        }
    }
}

// Handle API requests
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

$productManager = new ProductManager();

switch ($method) {
    case 'GET':
        if ($action === 'products') {
            $productManager->getProducts();
        } elseif ($action === 'categories') {
            $productManager->getCategories();
        } elseif ($action === 'inventory-stats') {
            $productManager->getInventoryStats();
        }
        break;
        
    case 'POST':
        $data = json_decode(file_get_contents('php://input'), true);
        if ($action === 'add') {
            $productManager->addProduct($data);
        }
        break;
        
    case 'PUT':
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $_GET['id'] ?? '';
        if ($action === 'update') {
            $productManager->updateProduct($id, $data);
        } elseif ($action === 'stock') {
            $productManager->updateStock($id, $data['stock']);
        }
        break;
        
    case 'DELETE':
        $id = $_GET['id'] ?? '';
        if ($action === 'delete') {
            $productManager->deleteProduct($id);
        }
        break;
        
    default:
        echo json_encode(['error' => 'Invalid request method']);
        break;
}
?>

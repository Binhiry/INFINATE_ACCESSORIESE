const express = require('express');
const pool = require('./db');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cors = require('cors');

const app = express();
const PORT = 3000;

const PIC_DIR = path.join(__dirname, '..', 'pic');
if (!fs.existsSync(PIC_DIR)) {
  fs.mkdirSync(PIC_DIR, { recursive: true });
}

const AVATAR_DIR = path.join(__dirname, '..', 'avatar');
if (!fs.existsSync(AVATAR_DIR)) {
  fs.mkdirSync(AVATAR_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, PIC_DIR),
  filename: (req, _file, cb) => {
    const productId = req.params.id || req.body.product_id || 'temp';
    cb(null, `${productId}.jpg`);
  },
});

const avatarUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, AVATAR_DIR),
    filename: (_req, _file, cb) => {
      // 先用临时名存储，路由处理 req.body 后再重命名
      cb(null, `_tmp_${Date.now()}_${Math.random().toString(36).slice(2)}.jpg`);
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
});
const upload = multer({ storage, limits: { fileSize: 10 * 1024 * 1024 } });

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/pic', express.static(PIC_DIR));
app.use('/avatar', express.static(AVATAR_DIR));
app.use(express.static(path.join(__dirname, '..')));  // 提供 HTML/JS/CSS 等静态文件

// 用户头像上传API
app.post('/api/upload-avatar', avatarUpload.single('avatar'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: '没有上传文件' });
    }
    const userId = req.body.userId;
    if (!userId) {
      // 删除临时文件
      if (req.file.path && fs.existsSync(req.file.path)) fs.unlinkSync(req.file.path);
      return res.status(400).json({ success: false, error: '缺少用户ID' });
    }
    const filename = `${userId}.jpg`;
    const destPath = path.join(AVATAR_DIR, filename);
    // 如果目标文件已存在，先删除
    if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
    // 将临时文件重命名为最终文件名
    fs.renameSync(req.file.path, destPath);
    res.json({ success: true, filename: filename, url: `/avatar/${filename}` });
  } catch (error) {
    console.error('头像上传失败:', error);
    // 尝试清理临时文件
    if (req.file && req.file.path && fs.existsSync(req.file.path)) {
      try { fs.unlinkSync(req.file.path); } catch (_) {}
    }
    res.status(500).json({ success: false, error: error.message });
  }
});

// CORS - allow all origins for development
app.use((_req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (_req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }
  next();
});

// health
app.get('/api/health', async (_req, res) => {
  try {
    await pool.query('SELECT 1');
    res.send('OK - Database connected');
  } catch (error) {
    res.status(500).send('Database connection failed: ' + error.message);
  }
});

// 统一映射商品行：在每行上补充 product_id（指向 id）以及前端需要的展示字段
function mapProductRow(p) {
  if (!p) return p;
  return {
    ...p,
    product_id: p.id,
    style: p.style || p.category || '',
    formatted_price: `¥ ${Number(p.price || 0).toFixed(2)}`,
    formatted_original_price: p.original_price ? `¥ ${Number(p.original_price).toFixed(2)}` : null,
  };
}

// image upload
app.post('/api/upload/:id', upload.single('image'), async (req, res) => {
  try {
    const productId = req.params.id;
    if (!req.file) {
      return res.status(400).json({ success: false, error: '请选择图片文件' });
    }
    const imageUrl = `pic/${productId}.jpg`;
    await pool.query('UPDATE products SET image_url = ? WHERE id = ?', [imageUrl, productId]);
    res.json({ success: true, image_url: imageUrl });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// categories
app.get('/api/categories', async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT DISTINCT category FROM products WHERE category IS NOT NULL AND category <> "" ORDER BY category');
    res.json({ success: true, data: rows.map((r) => r.category) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// styles
app.get('/api/styles', async (_req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT COALESCE(NULLIF(style, ''), category) AS style_name, COUNT(*) AS cnt
      FROM products
      WHERE COALESCE(NULLIF(style, ''), category) IS NOT NULL
      GROUP BY COALESCE(NULLIF(style, ''), category)
      ORDER BY cnt DESC, style_name ASC
    `);

    const visualMap = {
      '哥特暗黑': { icon: '🦇', tag: '暗系', gradient: 'sc-gothic' },
      '洛丽塔': { icon: '🎀', tag: '甜系', gradient: 'sc-lolita' },
      '朋克': { icon: '⛓️', tag: '街头系', gradient: 'sc-punk' },
      '原宿': { icon: '🌸', tag: '街头系', gradient: 'sc-harajuku' },
      '赛博朋克': { icon: '🤖', tag: '未来系', gradient: 'sc-cyber' },
      'Visual Kei': { icon: '🎸', tag: '暗系', gradient: 'sc-vkei' },
      '蒸汽朋克': { icon: '⚙️', tag: '复古系', gradient: 'sc-steam' },
      '田园风': { icon: '🌿', tag: '自然系', gradient: 'sc-cottagecore' },
      '暗潮': { icon: '🌙', tag: '暗系', gradient: 'sc-darkwave' },
    };

    const data = rows.map((r) => {
      const name = r.style_name;
      const visual = visualMap[name] || { icon: '🖤', tag: '其他', gradient: 'sc-gothic' };
      return {
        name,
        icon: visual.icon,
        tag: visual.tag,
        count: Number(r.cnt || 0),
        gradient: visual.gradient,
      };
    });

    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// products - list
app.get('/api/products', async (req, res) => {
  try {
    const { category, style, limit } = req.query;
    let sql = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    if (category) {
      sql += ' AND category = ?';
      params.push(category);
    }

    if (style) {
      sql += ' AND COALESCE(NULLIF(style, ""), category) = ?';
      params.push(style);
    }

    if (limit) {
      sql += ' ORDER BY id DESC LIMIT ?';
      params.push(Number(limit));
    } else {
      sql += ' ORDER BY id DESC';
    }

    const [rows] = await pool.query(sql, params);
    res.json({ success: true, data: rows.map(mapProductRow) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// products - next id（基于 pic/ 目录中最大数字文件名 + 1，保证与图片一一对应）
app.get('/api/products/next-id', async (_req, res) => {
  try {
    const nextId = getNextProductIdFromPics();
    res.json({ success: true, next_id: nextId });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, next_id: 1 });
  }
});

// featured products
app.get('/api/featured', async (req, res) => {
  try {
    const limit = Number(req.query.limit || 8);
    const [rows] = await pool.query('SELECT * FROM products ORDER BY id DESC LIMIT ?', [limit]);
    res.json({ success: true, data: rows.map((p) => ({ ...mapProductRow(p), is_new: false })) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// new arrivals
app.get('/api/new-arrivals', async (req, res) => {
  try {
    const limit = Number(req.query.limit || 12);
    const [rows] = await pool.query('SELECT * FROM products ORDER BY id DESC LIMIT ?', [limit]);
    res.json({ success: true, data: rows.map((p) => ({ ...mapProductRow(p), is_new: true })) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// search
app.get('/api/search', async (req, res) => {
  try {
    const { q = '', category, style, min_price, max_price } = req.query;
    let sql = 'SELECT * FROM products WHERE 1=1';
    const params = [];

    if (q) {
      const keyword = `%${q}%`;
      sql += ' AND (name LIKE ? OR description LIKE ? OR category LIKE ? OR brand LIKE ?)';
      params.push(keyword, keyword, keyword, keyword);
    }

    if (category && category !== 'all') {
      sql += ' AND category = ?';
      params.push(category);
    }

    if (style && style !== 'all') {
      sql += ' AND COALESCE(NULLIF(style, ""), category) = ?';
      params.push(style);
    }

    if (min_price !== undefined && min_price !== null && min_price !== '') {
      sql += ' AND price >= ?';
      params.push(Number(min_price));
    }

    if (max_price !== undefined && max_price !== null && max_price !== '') {
      sql += ' AND price <= ?';
      params.push(Number(max_price));
    }

    sql += ' ORDER BY id DESC LIMIT 50';

    const [rows] = await pool.query(sql, params);
    res.json({ success: true, data: rows.map(mapProductRow) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// homepage stats
app.get('/api/stats', async (_req, res) => {
  try {
    const [[totalProducts]] = await pool.query('SELECT COUNT(*) AS cnt FROM products');
    const [[newProducts]] = await pool.query('SELECT COUNT(*) AS cnt FROM products WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)');
    const [[monthlyOrders]] = await pool.query('SELECT COUNT(*) AS cnt FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)');
    const [[totalUsers]] = await pool.query('SELECT COUNT(*) AS cnt FROM users');

    res.json({
      success: true,
      data: {
        total_products: Number(totalProducts.cnt || 0),
        new_products: Number(newProducts.cnt || 0),
        monthly_orders: Number(monthlyOrders.cnt || 0),
        total_users: Number(totalUsers.cnt || 0),
      },
    });
  } catch (_error) {
    res.json({
      success: true,
      data: {
        total_products: 0,
        new_products: 0,
        monthly_orders: 0,
        total_users: 0,
      },
    });
  }
});

// products - detail
app.get('/api/products/:id', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    if (!rows.length) {
      return res.status(404).json({ success: false, error: '商品不存在' });
    }
    res.json({ success: true, data: mapProductRow(rows[0]) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// products - create
// 读取 pic/ 目录中所有 jpg 文件，返回数字 id 数组（去重升序）
function getPicIds() {
  try {
    if (!fs.existsSync(PIC_DIR)) return [];
    return fs.readdirSync(PIC_DIR)
      .filter(f => /\.jpe?g$/i.test(f))
      .map(f => {
        // 同时支持 "1.jpg" 和 "1.1.jpg"（取首段作为商品 id）
        const base = f.replace(/\.jpe?g$/i, '');
        const head = base.split('.')[0];
        const n = parseInt(head, 10);
        return isNaN(n) ? null : n;
      })
      .filter(n => n !== null)
      .sort((a, b) => a - b);
  } catch (e) {
    console.warn('读取 pic 目录失败:', e.message);
    return [];
  }
}

// 以 pic/ 目录中最大数字文件名 + 1 显式生成新商品 id（保证 pic/{id}.jpg 一一对应）
function getNextProductIdFromPics() {
  const ids = getPicIds();
  if (!ids.length) return 1;
    return ids[ids.length - 1] + 1;
  }

// 通用工具：以 pic/ 目录决定的新 id 显式插入；带主键冲突重试
async function insertProductWithNextId(product) {
  const MAX_RETRY = 5;
  for (let i = 0; i < MAX_RETRY; i++) {
    const newId = getNextProductIdFromPics();
    try {
      const [result] = await pool.query(
        `INSERT INTO products
        (id, name, stock, price, category, brand, image_url, description, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [newId, product.name, product.stock, product.price, product.category, product.brand, product.image_url, product.description, product.status],
      );
      return { id: newId, insertId: result.insertId, attempts: i + 1 };
    } catch (err) {
      if (err && (err.code === 'ER_DUP_ENTRY' || err.errno === 1062)) {
        console.warn(`insertProductWithNextId: 主键 ${newId} 冲突，重试 (${i + 1}/${MAX_RETRY})`);
        continue;
      }
      throw err;
    }
  }
  throw new Error('生成新商品 id 失败：已达最大重试次数');
}

app.post('/api/products', async (req, res) => {
  try {
    const {
      name,
      stock = 0,
      price = 0,
      category = '',
      brand = '',
      image_url = '',
      description = '',
      status = 'active',
      style = '',
    } = req.body;

    if (!name) {
      return res.status(400).json({ success: false, error: '商品名称不能为空' });
    }

    const finalCategory = category || style || '';
    // 服务端用 MAX(id)+1 显式分配新 id（带并发重试），不再依赖 AUTO_INCREMENT
    const inserted = await insertProductWithNextId({
      name,
      stock,
      price,
      category: finalCategory,
      brand,
      image_url,
      description,
      status,
    });
    console.log(`新商品创建成功: id=${inserted.id} (第 ${inserted.attempts} 次尝试)`);

    res.json({ success: true, id: inserted.id, product_id: inserted.id });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// products - update
app.put('/api/products/:id', async (req, res) => {
  try {
    const id = req.params.id;
    const fields = { ...req.body };
    if (!fields.category && fields.style) {
      fields.category = fields.style;
    }
    delete fields.style;
    delete fields.sizes;
    delete fields.colors;
    delete fields.original_price;
    delete fields.seo_keywords;
    delete fields.seo_description;

    const keys = Object.keys(fields);
    if (!keys.length) {
      return res.json({ success: true });
    }
    const setSql = keys.map((k) => `${k} = ?`).join(', ');
    const values = keys.map((k) => fields[k]);
    values.push(id);
    await pool.query(`UPDATE products SET ${setSql} WHERE id = ?`, values);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// products - delete
app.delete('/api/products/:id', async (req, res) => {
  try {
    // 先获取商品信息，获取图片路径
    const [products] = await pool.query('SELECT image_url FROM products WHERE id = ?', [req.params.id]);
    if (products.length > 0 && products[0].image_url) {
      const imagePath = path.join(__dirname, '..', products[0].image_url);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }
    // 删除商品记录
    await pool.query('DELETE FROM products WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// product comments（通过 JOIN users / products 获取用户名和商品名）
app.get('/api/products/:id/comments', async (req, res) => {
  try {
    const productId = req.params.id;
    const [rows] = await pool.query(
      `SELECT
         r.id, r.user_id, r.product_id, r.order_id, r.content, r.rating, r.created_at,
         u.username AS user_name,
         p.name AS product_name
       FROM reviews r
       LEFT JOIN users u ON r.user_id = u.user_id
       LEFT JOIN products p ON r.product_id = p.id
       WHERE r.product_id = ?
       ORDER BY r.id DESC`,
      [productId]
    );
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// 新增评论（兼容历史表结构；不删除已有数据）
app.post('/api/reviews', async (req, res) => {
  try {
    console.log('收到评论提交请求:', req.body);
    const { user_id, product_id, order_id, content, rating } = req.body;

    // 若 reviews 表不存在则创建（不会删除已有数据）
    await pool.query(`
      CREATE TABLE IF NOT EXISTS reviews (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        product_id INT,
        order_id INT,
        content TEXT,
        rating INT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 兜底：若表存在但缺少字段，尝试添加（使用 ADD COLUMN IF NOT EXISTS 兼容 MySQL 8）
    const [colCheck] = await pool.query(
      `SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reviews'`
    );
    const existingCols = new Set(colCheck.map(c => c.COLUMN_NAME));
    const need = ['user_id','product_id','order_id','content','rating','created_at'];
    for (const col of need) {
      if (!existingCols.has(col)) {
        let def = 'TEXT';
        if (col === 'user_id' || col === 'product_id' || col === 'order_id' || col === 'rating') def = 'INT';
        if (col === 'created_at') def = 'DATETIME DEFAULT CURRENT_TIMESTAMP';
        try {
          await pool.query(`ALTER TABLE reviews ADD COLUMN ${col} ${def}`);
        } catch (e) {
          console.warn(`ADD COLUMN ${col} 失败:`, e.message);
        }
      }
    }

    const [result] = await pool.query(
      'INSERT INTO reviews (user_id, product_id, order_id, content, rating) VALUES (?, ?, ?, ?, ?)',
      [user_id, product_id, order_id || null, content, rating]
    );
    console.log('评论插入成功，ID:', result.insertId);
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    console.error('评论插入失败:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// 评论列表（JOIN users/products 返回完整信息；支持 order_id / product_id / user_id 过滤）
app.get('/api/reviews', async (req, res) => {
  try {
    const { order_id, product_id, user_id } = req.query;
    let sql = `
      SELECT
        r.id, r.user_id, r.product_id, r.order_id, r.content, r.rating, r.created_at,
        u.username AS user_name,
        p.name AS product_name,
        p.image_url AS product_image
      FROM reviews r
      LEFT JOIN users u ON r.user_id = u.user_id
      LEFT JOIN products p ON r.product_id = p.id
      WHERE 1=1
    `;
    const params = [];
    if (order_id) { sql += ' AND r.order_id = ?'; params.push(order_id); }
    if (product_id) { sql += ' AND r.product_id = ?'; params.push(product_id); }
    if (user_id) { sql += ' AND r.user_id = ?'; params.push(user_id); }
    sql += ' ORDER BY r.id DESC';

    const [rows] = await pool.query(sql, params);
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// 删除评论
app.delete('/api/reviews/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM reviews WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 审核（通过/拒绝）评论
app.put('/api/reviews/:id', async (req, res) => {
  try {
    // reviews 表无 status 字段，前端审核功能已禁用
    res.json({ success: true, message: '评论表无审核字段，跳过状态更新' });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// related products
app.get('/api/products/:id/related', async (req, res) => {
  try {
    const [[base]] = await pool.query('SELECT category FROM products WHERE id = ?', [req.params.id]);
    if (!base) {
      return res.json({ success: true, data: [] });
    }
    const [rows] = await pool.query('SELECT * FROM products WHERE id <> ? AND category = ? ORDER BY id DESC LIMIT 6', [req.params.id, base.category]);
    res.json({ success: true, data: rows.map(mapProductRow) });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

// orders - list/create/update/delete
app.get('/api/orders', async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM orders ORDER BY id DESC');
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

app.post('/api/orders', async (req, res) => {
  try {
    const { order_number, user_id, contact, address, total_amount = 0, status = 'pending', payment_method = '' } = req.body;
    const [result] = await pool.query(
      'INSERT INTO orders (order_number, user_id, contact, address, total_amount, status, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [order_number, user_id, contact, address, total_amount, status, payment_method],
    );
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/orders/:id', async (req, res) => {
  try {
    const keys = Object.keys(req.body);
    if (!keys.length) return res.json({ success: true });
    const setSql = keys.map((k) => `${k} = ?`).join(', ');
    const values = keys.map((k) => req.body[k]);
    values.push(req.params.id);
    await pool.query(`UPDATE orders SET ${setSql} WHERE id = ?`, values);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/orders/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM orders WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// order-items - create（兼容历史表结构；不删除已有数据）
app.post('/api/order-items', async (req, res) => {
  try {
    const { order_id, product_id, product_name, product_size, product_style, quantity, price } = req.body;

    // 1) 若表不存在则创建
    await pool.query(`
      CREATE TABLE IF NOT EXISTS order_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        order_id INT,
        product_id INT,
        quantity INT DEFAULT 1,
        price DECIMAL(10,2),
        product_name VARCHAR(255),
        product_size VARCHAR(50),
        product_style VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // 2) 兜底：若表存在但缺少字段，尝试添加
    const [colCheck] = await pool.query(
      `SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS
       WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'order_items'`
    );
    const existingCols = new Set(colCheck.map(c => c.COLUMN_NAME));
    const want = {
      order_id: 'INT',
      product_id: 'INT',
      quantity: 'INT DEFAULT 1',
      price: 'DECIMAL(10,2)',
      product_name: 'VARCHAR(255)',
      product_size: 'VARCHAR(50)',
      product_style: 'VARCHAR(255)',
      created_at: 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP'
    };
    for (const [col, def] of Object.entries(want)) {
      if (!existingCols.has(col)) {
        try {
          await pool.query(`ALTER TABLE order_items ADD COLUMN ${col} ${def}`);
        } catch (e) {
          console.warn(`order_items ADD COLUMN ${col} 失败:`, e.message);
        }
      }
    }

    // 3) 插入（只插入实际存在的字段）
    const insertCols = ['order_id', 'product_id', 'product_name', 'product_size', 'product_style', 'quantity', 'price'];
    const insertVals = [
      order_id,
      product_id,
      product_name || '',
      product_size || '均码',
      product_style || '',
      quantity || 1,
      Number(price || 0)
    ];
    const placeholders = insertCols.map(() => '?').join(', ');
    const [result] = await pool.query(
      `INSERT INTO order_items (${insertCols.join(', ')}) VALUES (${placeholders})`,
      insertVals
    );
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// order-items - list by order
app.get('/api/order-items', async (req, res) => {
  try {
    console.log('GET /api/order-items - 请求参数:', req.query);

    // 检查order_items表是否存在
    try {
      await pool.query('SELECT 1 FROM order_items LIMIT 1');
    } catch (e) {
      console.error('order_items表不存在:', e.message);
      // 创建order_items表
      await pool.query(`
        CREATE TABLE IF NOT EXISTS order_items (
          id INT AUTO_INCREMENT PRIMARY KEY,
          order_id INT,
          product_id INT,
          product_name VARCHAR(255),
          product_size VARCHAR(50),
          product_style VARCHAR(255),
          quantity INT DEFAULT 1,
          price DECIMAL(10,2),
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      `);
      console.log('order_items表创建成功');
    }

    const { order_id, order_number } = req.query;
    // 通过 JOIN products 取图片、当前价格、product_id；并把 oi.id 当作行主键一并返回
    let sql = `
      SELECT
        oi.id            AS order_item_id,
        oi.order_id,
        oi.product_id    AS product_id,
        oi.product_size,
        oi.product_style,
        oi.quantity,
        oi.price,
        p.id             AS product_pk,
        p.name           AS product_name,
        p.image_url,
        p.price          AS current_price,
        p.category,
        p.brand
      FROM order_items oi
      LEFT JOIN products p ON oi.product_id = p.id
      WHERE 1=1
    `;
    const params = [];

    if (order_id) {
      sql += ' AND oi.order_id = ?';
      params.push(order_id);
    }
    // order_items表没有order_number字段，暂忽略

    sql += ' ORDER BY oi.id ASC';

    const [rows] = await pool.query(sql, params);

    // 为每条记录补充前端展示字段
    const data = rows.map((r) => {
      const productId = r.product_id || r.product_pk;
      return {
        ...r,
        product_id: productId,
        product_name: r.product_name || r.product_name || '商品',
        formatted_price: `¥ ${Number(r.price || 0).toFixed(2)}`,
        image_url: r.image_url || '',
        subtotal: Number((Number(r.price || 0) * Number(r.quantity || 1)).toFixed(2)),
      };
    });

    res.json({ success: true, data });
  } catch (error) {
    console.error('GET /api/order-items - 错误:', error);
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

async function getUsersTableMeta() {
  const [columns] = await pool.query('SHOW COLUMNS FROM users');
  const fields = columns.map((c) => c.Field);
  const primaryKey = fields.includes('id')
    ? 'id'
    : (fields.includes('user_id') ? 'user_id' : fields[0]);
  return { fields, primaryKey };
}

// users - list/create/update/delete
app.get('/api/users', async (_req, res) => {
  try {
    const { primaryKey } = await getUsersTableMeta();
    const [rows] = await pool.query(`SELECT * FROM users ORDER BY ${primaryKey} DESC`);
    res.json({ success: true, data: rows });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message, data: [] });
  }
});

app.post('/api/users', async (req, res) => {
  try {
    const { fields, primaryKey } = await getUsersTableMeta();
    const payload = {
      username: req.body.username,
      password: req.body.password,
      email: req.body.email || '',
      phone: req.body.phone || '',
      address: req.body.address || '',
      member_level: req.body.member_level || '普通',
      avatar_url: req.body.avatar_url || '',
      status: req.body.status || 'active',
    };

    // 若 users 表有 user_id 列（且非主键、非自动生成），自动分配 MAX(user_id)+1
    if (fields.includes('user_id') && primaryKey !== 'user_id') {
      const [[maxRow]] = await pool.query('SELECT COALESCE(MAX(user_id), 0) AS mx FROM users');
      const nextUserId = (Number((maxRow && maxRow.mx) || 0)) + 1;
      payload.user_id = nextUserId;
    }

    const insertKeys = Object.keys(payload).filter((key) => fields.includes(key) && payload[key] !== undefined);
    if (!insertKeys.includes('username') || !insertKeys.includes('password')) {
      return res.status(400).json({ success: false, error: 'users表缺少username/password字段，无法注册' });
    }

    const values = insertKeys.map((key) => payload[key]);

    if (insertKeys.length !== values.length) {
      return res.status(500).json({ success: false, error: '字段和值数量不匹配，无法插入' });
    }

    // Check if primary key is auto-incrementing
    const [[pkColumn]] = await pool.query(`SHOW COLUMNS FROM users WHERE Field = '${primaryKey}'`);
    const isAutoInc = pkColumn && String(pkColumn.Extra || '').toUpperCase().includes('AUTO_INCREMENT');

    if (!isAutoInc) {
      // 主键非自增，需显式插入主键值
      insertKeys.push(primaryKey);
      if (primaryKey === 'user_id') {
        const [[maxRow]] = await pool.query('SELECT COALESCE(MAX(user_id), 0) AS mx FROM users');
        const nextPkId = (Number((maxRow && maxRow.mx) || 0)) + 1;
        values.push(nextPkId);
      } else {
        values.push(null);
      }
    }

    // 在 push 之后重新生成 placeholders，保证列数与占位符数一致
    const placeholders = insertKeys.map(() => '?').join(', ');
    const [result] = await pool.query(`INSERT INTO users (${insertKeys.join(', ')}) VALUES (${placeholders})`, values);
    res.json({ success: true, id: result.insertId });
  } catch (error) {
    console.error('[POST /api/users] 注册失败:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/users/:id', async (req, res) => {
  try {
    const { fields, primaryKey } = await getUsersTableMeta();
    console.log('PUT /api/users/:id - 字段列表:', fields);
    console.log('PUT /api/users/:id - 主键:', primaryKey);
    console.log('PUT /api/users/:id - 请求体:', req.body);
    console.log('PUT /api/users/:id - 参数ID:', req.params.id);

    const keys = Object.keys(req.body).filter((k) => fields.includes(k) && k !== primaryKey);
    console.log('PUT /api/users/:id - 有效字段:', keys);

    if (!keys.length) {
      console.log('PUT /api/users/:id - 没有有效字段需要更新');
      return res.json({ success: true });
    }

    const setSql = keys.map((k) => `${k} = ?`).join(', ');
    const values = keys.map((k) => req.body[k]);
    values.push(req.params.id);

    console.log('PUT /api/users/:id - SQL:', `UPDATE users SET ${setSql} WHERE ${primaryKey} = ?`);
    console.log('PUT /api/users/:id - 值:', values);

    await pool.query(`UPDATE users SET ${setSql} WHERE ${primaryKey} = ?`, values);
    console.log('PUT /api/users/:id - 更新成功');
    res.json({ success: true });
  } catch (error) {
    console.error('PUT /api/users/:id - 错误:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

app.delete('/api/users/:id', async (req, res) => {
  try {
    const { primaryKey } = await getUsersTableMeta();
    await pool.query(`DELETE FROM users WHERE ${primaryKey} = ?`, [req.params.id]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 系统设置
app.get('/api/system-info', async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT key_name, value FROM system_info');
    const data = {};
    for (const row of rows) data[row.key_name] = row.value;
    res.json({ success: true, data });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.put('/api/system-info/:key', async (req, res) => {
  try {
    const { value } = req.body;
    await pool.query('UPDATE system_info SET value = ? WHERE key_name = ?', [value, req.params.key]);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 批量保存系统设置
app.put('/api/system-info', async (req, res) => {
  try {
    const settings = req.body; // { key1: value1, key2: value2, ... }
    const keys = Object.keys(settings);
    if (!keys.length) return res.json({ success: true });
    for (const key of keys) {
      await pool.query('UPDATE system_info SET value = ? WHERE key_name = ?', [settings[key], key]);
    }
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// dashboard summary
app.get('/api/admin/dashboard', async (_req, res) => {
  try {
    console.log('开始查询数据库统计数据...');
    const [[sales]] = await pool.query("SELECT IFNULL(SUM(total_amount),0) AS sales_total FROM orders WHERE status = 'completed'");
    console.log('销售总额:', sales);
    const [[orders]] = await pool.query('SELECT COUNT(*) AS orders_total FROM orders');
    console.log('订单总数:', orders);
    const [[users]] = await pool.query('SELECT COUNT(*) AS users_total FROM users');
    console.log('用户总数:', users);

    // 获取近7日销售趋势
    const [salesTrend] = await pool.query(`
      SELECT
        DATE(created_at) AS date,
        SUM(total_amount) AS amount
      FROM orders
      WHERE status = 'completed'
        AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
      GROUP BY DATE(created_at)
      ORDER BY date ASC
    `);
    console.log('销售趋势:', salesTrend);

    // 获取风格销售占比 - 添加错误处理
    let styleSalesObj = {};
    try {
      // 先获取所有可能的风格分类
      const [allStyles] = await pool.query(`
        SELECT DISTINCT COALESCE(NULLIF(style, ''), category) AS style_name
        FROM products
        WHERE COALESCE(NULLIF(style, ''), category) IS NOT NULL
          AND COALESCE(NULLIF(style, ''), category) <> ''
          AND COALESCE(NULLIF(style, ''), category) NOT IN ('debug', 'test')
        ORDER BY style_name
      `);

      // 初始化所有风格为0
      allStyles.forEach(row => {
        styleSalesObj[row.style_name] = 0;
      });

      // 获取所有商品的风格数量（不限制订单状态）
      const [styleSales] = await pool.query(`
        SELECT
          COALESCE(NULLIF(style, ''), category) AS style_name,
          COUNT(*) AS count
        FROM products
        WHERE COALESCE(NULLIF(style, ''), category) IS NOT NULL
          AND COALESCE(NULLIF(style, ''), category) <> ''
          AND COALESCE(NULLIF(style, ''), category) NOT IN ('debug', 'test')
        GROUP BY COALESCE(NULLIF(style, ''), category)
      `);
      console.log('风格销售:', styleSales);

      // 更新有数据的风格
      styleSales.forEach(row => {
        if (styleSalesObj.hasOwnProperty(row.style_name)) {
          styleSalesObj[row.style_name] = row.count;
        }
      });
    } catch (e) {
      console.log('风格销售查询失败，使用默认空数据:', e.message);
    }

    const result = {
      success: true,
      data: {
        sales_total: sales.sales_total,
        orders_total: orders.orders_total,
        users_total: users.users_total,
        sales_trend: salesTrend.map(row => ({
          date: row.date,
          amount: Number(row.amount || 0)
        })),
        style_sales: styleSalesObj
      }
    };
    console.log('返回数据:', result);
    res.json(result);
  } catch (_e) {
    console.error('Dashboard API error:', _e);
    res.json({
      success: true,
      data: {
        sales_total: 0,
        orders_total: 0,
        users_total: 0,
        sales_trend: [],
        style_sales: {}
      }
    });
  }
});

app.listen(PORT, () => {
  console.log(`API server running at http://localhost:${PORT}`);
});

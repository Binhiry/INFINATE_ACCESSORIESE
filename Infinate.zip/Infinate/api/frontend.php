<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

class Database {
    private $host = 'localhost';
    private $port = '3306';
    private $dbname = 'INFINATE';
    private $username = 'root';
    private $password = '1234';
    private $conn;

    public function connect() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};port={$this->port};dbname={$this->dbname};charset=utf8mb4", 
                                 $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $this->conn;
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]);
            return null;
        }
    }
}

class FrontendAPI {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->connect();
    }

    // Get featured products for homepage
    public function getFeaturedProducts() {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category = c.name 
                WHERE p.status = 'active' AND (p.tags LIKE '%热销%' OR p.sales > 50)
                ORDER BY p.sales DESC 
                LIMIT 8
            ");
            $stmt->execute();
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format products
            foreach ($products as &$product) {
                $product['formatted_price'] = '¥ ' . number_format($product['price'], 2);
                $product['formatted_original_price'] = $product['original_price'] ? '¥ ' . number_format($product['original_price'], 2) : null;
                $product['image_url'] = isset($product['image_url']) ? trim((string)$product['image_url']) : '';
            }
            
            echo json_encode(['success' => true, 'data' => $products]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch featured products: ' . $e->getMessage()]);
        }
    }

    // Get new arrivals
    public function getNewArrivals($limit = 12) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category = c.name 
                WHERE p.status = 'active' AND (p.tags LIKE '%新品%' OR p.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY))
                ORDER BY p.created_at DESC 
                LIMIT ?
            ");
            $stmt->execute([$limit]);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format products
            foreach ($products as &$product) {
                $product['formatted_price'] = '¥ ' . number_format($product['price'], 2);
                $product['formatted_original_price'] = $product['original_price'] ? '¥ ' . number_format($product['original_price'], 2) : null;
                $product['image_url'] = isset($product['image_url']) ? trim((string)$product['image_url']) : '';
                $product['is_new'] = true;
            }
            
            echo json_encode(['success' => true, 'data' => $products]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch new arrivals: ' . $e->getMessage()]);
        }
    }

    // Get products by category
    public function getProductsByCategory($category = null, $style = null, $limit = 50) {
        try {
            $sql = "
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category = c.name 
                WHERE p.status = 'active'
            ";
            $params = [];
            
            if ($category && $category !== 'all') {
                $sql .= " AND p.category = ?";
                $params[] = $category;
            }
            
            if ($style && $style !== 'all') {
                $sql .= " AND p.style = ?";
                $params[] = $style;
            }
            
            $sql .= " ORDER BY p.created_at DESC LIMIT ?";
            $params[] = $limit;
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format products
            foreach ($products as &$product) {
                $product['formatted_price'] = '¥ ' . number_format($product['price'], 2);
                $product['formatted_original_price'] = $product['original_price'] ? '¥ ' . number_format($product['original_price'], 2) : null;
                $product['image_url'] = isset($product['image_url']) ? trim((string)$product['image_url']) : '';
                $product['is_new'] = (strtotime($product['created_at']) > strtotime('-30 days'));
            }
            
            echo json_encode(['success' => true, 'data' => $products]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch products: ' . $e->getMessage()]);
        }
    }

    // Get categories with product counts
    public function getCategoriesWithCounts() {
        try {
            $stmt = $this->db->prepare("
                SELECT c.*, COUNT(p.id) as product_count
                FROM categories c
                LEFT JOIN products p ON c.name = p.category AND p.status = 'active'
                WHERE c.status = 'active'
                GROUP BY c.id
                ORDER BY c.sort_order, c.name
            ");
            $stmt->execute();
            $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Add style information
            $styles = ['哥特暗黑', '洛丽塔', '朋克', '原宿', '赛博朋克', 'Visual Kei', '蒸汽朋克', '田园风', '暗潮'];
            foreach ($categories as &$category) {
                $category['style_group'] = $this->getStyleGroup($category['name']);
            }
            
            echo json_encode(['success' => true, 'data' => $categories]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch categories: ' . $e->getMessage()]);
        }
    }

    // Get style information
    public function getStyles() {
        try {
            $styles = [
                ['name' => '哥特暗黑', 'icon' => '🦇', 'tag' => '暗系', 'count' => 0, 'gradient' => 'sc-gothic'],
                ['name' => '洛丽塔', 'icon' => '🎀', 'tag' => '甜系', 'count' => 0, 'gradient' => 'sc-lolita'],
                ['name' => '朋克', 'icon' => '⛓️', 'tag' => '街头系', 'count' => 0, 'gradient' => 'sc-punk'],
                ['name' => '原宿', 'icon' => '🌸', 'tag' => '街头系', 'count' => 0, 'gradient' => 'sc-harajuku'],
                ['name' => '赛博朋克', 'icon' => '🤖', 'tag' => '未来系', 'count' => 0, 'gradient' => 'sc-cyber'],
                ['name' => 'Visual Kei', 'icon' => '🎸', 'tag' => '暗系', 'count' => 0, 'gradient' => 'sc-vkei'],
                ['name' => '蒸汽朋克', 'icon' => '⚙️', 'tag' => '复古系', 'count' => 0, 'gradient' => 'sc-steam'],
                ['name' => '田园风', 'icon' => '🌿', 'tag' => '自然系', 'count' => 0, 'gradient' => 'sc-cottagecore'],
                ['name' => '暗潮', 'icon' => '🌙', 'tag' => '暗系', 'count' => 0, 'gradient' => 'sc-darkwave']
            ];

            // Get product counts for each style
            foreach ($styles as &$style) {
                $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM products WHERE style = ? AND status = 'active'");
                $stmt->execute([$style['name']]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                $style['count'] = (int)$result['count'];
            }
            
            echo json_encode(['success' => true, 'data' => $styles]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch styles: ' . $e->getMessage()]);
        }
    }

    // Search products
    public function searchProducts($query, $category = null, $style = null, $minPrice = null, $maxPrice = null) {
        try {
            $sql = "
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category = c.name 
                WHERE p.status = 'active' AND (
                    p.name LIKE ? OR 
                    p.description LIKE ? OR 
                    p.seo_keywords LIKE ? OR
                    p.tags LIKE ?
                )
            ";
            $params = ["%$query%", "%$query%", "%$query%", "%$query%"];
            
            if ($category && $category !== 'all') {
                $sql .= " AND p.category = ?";
                $params[] = $category;
            }
            
            if ($style && $style !== 'all') {
                $sql .= " AND p.style = ?";
                $params[] = $style;
            }
            
            if ($minPrice !== null) {
                $sql .= " AND p.price >= ?";
                $params[] = $minPrice;
            }
            
            if ($maxPrice !== null) {
                $sql .= " AND p.price <= ?";
                $params[] = $maxPrice;
            }
            
            $sql .= " ORDER BY p.sales DESC, p.created_at DESC LIMIT 50";
            
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Format products
            foreach ($products as &$product) {
                $product['formatted_price'] = '¥ ' . number_format($product['price'], 2);
                $product['formatted_original_price'] = $product['original_price'] ? '¥ ' . number_format($product['original_price'], 2) : null;
                $product['image_url'] = isset($product['image_url']) ? trim((string)$product['image_url']) : '';
                $product['is_new'] = (strtotime($product['created_at']) > strtotime('-30 days'));
            }
            
            echo json_encode(['success' => true, 'data' => $products]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Search failed: ' . $e->getMessage()]);
        }
    }

    // Get product details
    public function getProductDetails($id) {
        try {
            $stmt = $this->db->prepare("
                SELECT p.*, c.name as category_name 
                FROM products p 
                LEFT JOIN categories c ON p.category = c.name 
                WHERE p.id = ? AND p.status = 'active'
            ");
            $stmt->execute([$id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($product) {
                $product['formatted_price'] = '¥ ' . number_format($product['price'], 2);
                $product['formatted_original_price'] = $product['original_price'] ? '¥ ' . number_format($product['original_price'], 2) : null;
                $product['image_url'] = isset($product['image_url']) ? trim((string)$product['image_url']) : '';
                $product['is_new'] = (strtotime($product['created_at']) > strtotime('-30 days'));
                
                // Get related products
                $relatedStmt = $this->db->prepare("
                    SELECT p.id, p.name, p.price, p.image_url, p.style
                    FROM products p 
                    WHERE p.style = ? AND p.id != ? AND p.status = 'active'
                    ORDER BY p.sales DESC 
                    LIMIT 4
                ");
                $relatedStmt->execute([$product['style'], $product['id']]);
                $related = $relatedStmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($related as &$relProduct) {
                    $relProduct['formatted_price'] = '¥ ' . number_format($relProduct['price'], 2);
                    $relProduct['image_url'] = isset($relProduct['image_url']) ? trim((string)$relProduct['image_url']) : '';
                }
                
                echo json_encode(['success' => true, 'data' => $product, 'related' => $related]);
            } else {
                echo json_encode(['error' => 'Product not found']);
            }
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch product details: ' . $e->getMessage()]);
        }
    }

    // Get trending products
    public function getTrendingProducts() {
        try {
            $stmt = $this->db->prepare("
                SELECT p.name, p.style, COUNT(o.id) as order_count, SUM(o.total_amount) as revenue
                FROM products p
                LEFT JOIN orders o ON JSON_CONTAINS(o.product_info, JSON_QUOTE(p.name))
                WHERE p.status = 'active' AND o.created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY p.id
                ORDER BY order_count DESC, revenue DESC
                LIMIT 5
            ");
            $stmt->execute();
            $trending = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['success' => true, 'data' => $trending]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch trending products: ' . $e->getMessage()]);
        }
    }

    // Get statistics for homepage
    public function getHomepageStats() {
        try {
            $stats = [];
            
            // Total products
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM products WHERE status = 'active'");
            $stmt->execute();
            $stats['total_products'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            // New products this month
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM products WHERE status = 'active' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
            $stmt->execute();
            $stats['new_products'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            // Total orders this month
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)");
            $stmt->execute();
            $stats['monthly_orders'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            // Total users
            $stmt = $this->db->prepare("SELECT COUNT(*) as count FROM users WHERE status = 'active'");
            $stmt->execute();
            $stats['total_users'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            echo json_encode(['success' => true, 'data' => $stats]);
        } catch(PDOException $e) {
            echo json_encode(['error' => 'Failed to fetch stats: ' . $e->getMessage()]);
        }
    }

    private function getStyleGroup($category) {
        $darkStyles = ['哥特暗黑', 'Visual Kei', '暗潮'];
        $sweetStyles = ['洛丽塔'];
        $streetStyles = ['朋克', '原宿'];
        $futureStyles = ['赛博朋克'];
        $vintageStyles = ['蒸汽朋克'];
        $naturalStyles = ['田园风'];
        
        if (in_array($category, $darkStyles)) return '暗系';
        if (in_array($category, $sweetStyles)) return '甜系';
        if (in_array($category, $streetStyles)) return '街头系';
        if (in_array($category, $futureStyles)) return '未来系';
        if (in_array($category, $vintageStyles)) return '复古系';
        if (in_array($category, $naturalStyles)) return '自然系';
        
        return '其他';
    }
}

// Handle API requests
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';

$frontendAPI = new FrontendAPI();

switch ($method) {
    case 'GET':
        switch ($action) {
            case 'featured':
                $frontendAPI->getFeaturedProducts();
                break;
            case 'new-arrivals':
                $limit = $_GET['limit'] ?? 12;
                $frontendAPI->getNewArrivals($limit);
                break;
            case 'products':
                $category = $_GET['category'] ?? null;
                $style = $_GET['style'] ?? null;
                $frontendAPI->getProductsByCategory($category, $style);
                break;
            case 'categories':
                $frontendAPI->getCategoriesWithCounts();
                break;
            case 'styles':
                $frontendAPI->getStyles();
                break;
            case 'search':
                $query = $_GET['q'] ?? '';
                $category = $_GET['category'] ?? null;
                $style = $_GET['style'] ?? null;
                $minPrice = $_GET['min_price'] ?? null;
                $maxPrice = $_GET['max_price'] ?? null;
                $frontendAPI->searchProducts($query, $category, $style, $minPrice, $maxPrice);
                break;
            case 'product':
                $id = $_GET['id'] ?? '';
                $frontendAPI->getProductDetails($id);
                break;
            case 'trending':
                $frontendAPI->getTrendingProducts();
                break;
            case 'stats':
                $frontendAPI->getHomepageStats();
                break;
            default:
                echo json_encode(['error' => 'Invalid action']);
                break;
        }
        break;
        
    default:
        echo json_encode(['error' => 'Invalid request method']);
        break;
}
?>

// Node.js MySQL 配置文件
module.exports = {
  host: 'localhost',
  user: 'root',
  password: '1234',
  database: 'INFINATE',
  port: 3306
};

class ProductManager {
  constructor() {
    this.productsApi = 'http://localhost:3000/api/products';
    this.ordersApi = 'http://localhost:3000/api/orders';
    this.usersApi = 'http://localhost:3000/api/users';
    this.reviewsApi = 'http://localhost:3000/api/reviews';
    this.currentProducts = [];
    this.currentOrders = [];
    this.currentUsers = [];
    this.currentReviews = [];
    this.filteredProducts = [];
    this.filteredOrders = [];
    this.filteredUsers = [];
    this.editingProductId = null;
    this.init();
    this.initGlobalSearch();
  }

  init() {
    this.setupEventListeners();
    this.loadCategories();
    this.loadProducts();
    this.loadOrders();
    this.loadUsers();
    this.loadReviews();
    this.loadDashboardStats();
  }

  initGlobalSearch() {
    const searchInput = document.getElementById('global-search');
    if (!searchInput) return;

    searchInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        this.handleGlobalSearch(searchInput.value.trim());
      }
    });
  }

  handleGlobalSearch(query) {
    if (!query) return;

    const activeView = document.querySelector('.view.active');
    if (!activeView) return;

    const viewId = activeView.id;

    if (viewId === 'view-products') {
      this.filterProducts(query);
    } else if (viewId === 'view-orders') {
      this.filterOrders(query);
    } else if (viewId === 'view-users') {
      this.filterUsers(query);
    } else if (viewId === 'view-reviews') {
      this.filterReviews(query);
    } else {
      this.showMessage('请在商品、订单、用户或评价页面进行搜索', 'info');
    }
  }

  filterProducts(query) {
    this.filteredProducts = this.currentProducts.filter(p =>
      (p.name && p.name.toLowerCase().includes(query.toLowerCase())) ||
      (p.category && p.category.toLowerCase().includes(query.toLowerCase())) ||
      (p.style && p.style.toLowerCase().includes(query.toLowerCase())) ||
      (p.brand && p.brand.toLowerCase().includes(query.toLowerCase()))
    );
    this.updateProductsTable();
    this.showMessage(`找到 ${this.filteredProducts.length} 个商品`, 'success');
  }

  filterOrders(query) {
    this.filteredOrders = this.currentOrders.filter(o =>
      (o.order_number && o.order_number.toLowerCase().includes(query.toLowerCase())) ||
      (o.username && o.username.toLowerCase().includes(query.toLowerCase())) ||
      (o.user_id && String(o.user_id).includes(query))
    );
    this.updateOrdersTable();
    this.showMessage(`找到 ${this.filteredOrders.length} 个订单`, 'success');
  }

  filterUsers(query) {
    this.filteredUsers = this.currentUsers.filter(u =>
      (u.username && u.username.toLowerCase().includes(query.toLowerCase())) ||
      (u.email && u.email.toLowerCase().includes(query.toLowerCase())) ||
      (u.phone && u.phone.includes(query))
    );
    this.updateUsersTable();
    this.showMessage(`找到 ${this.filteredUsers.length} 个用户`, 'success');
  }

  filterReviews(query) {
    this.filteredReviews = this.currentReviews.filter(r =>
      (r.user_name && r.user_name.toLowerCase().includes(query.toLowerCase())) ||
      (r.product_name && r.product_name.toLowerCase().includes(query.toLowerCase())) ||
      (r.content && r.content.toLowerCase().includes(query.toLowerCase()))
    );
    this.updateReviewsTable();
    this.showMessage(`找到 ${this.filteredReviews.length} 条评价`, 'success');
  }

  setupEventListeners() {
    const submitBtn = document.querySelector('#view-add-product .form-btn');
    console.log('发布商品按钮:', submitBtn);
    if (submitBtn) {
      submitBtn.addEventListener('click', (e) => {
        console.log('发布商品按钮被点击');
        e.preventDefault();
        this.handleAddProduct();
      });
    } else {
      console.error('未找到发布商品按钮');
    }
    const productsTable = document.querySelector('#view-products tbody');
    if (productsTable) {
      productsTable.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-action]');
        if (!btn) return;
        const id = Number(btn.dataset.id);
        const action = btn.dataset.action;
        if (action === 'edit') this.editProduct(id);
        if (action === 'toggle') this.toggleProductStatus(id);
        if (action === 'stock') this.showStockModal(id);
        if (action === 'delete') this.deleteProduct(id);
      });
    }
    const reviewsTable = document.querySelector('#view-reviews tbody');
    if (reviewsTable) {
      reviewsTable.addEventListener('click', (e) => {
        const btn = e.target.closest('button[data-action]');
        if (!btn) return;
        const id = Number(btn.dataset.id);
        const action = btn.dataset.action;
        if (action === 'delete-review') this.deleteReview(id);
      });
    }
    // 订单筛选
    const orderStatusSelect = document.querySelector('#view-orders .form-select');
    if (orderStatusSelect) {
      orderStatusSelect.addEventListener('change', (e) => {
        this.filterOrders(e.target.value);
      });
    }
    // 导出Excel
    const exportBtn = document.querySelector('#view-orders .form-btn');
    if (exportBtn) {
      exportBtn.onclick = () => {
        this.exportOrdersToExcel();
      };
    }
    document.querySelectorAll('#view-orders .panel-tabs .ptab').forEach((tab) => {
      tab.addEventListener('click', (e) => {
        document.querySelectorAll('#view-orders .panel-tabs .ptab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        const txt = tab.textContent;
        const status = txt.includes('全部') ? '全部状态' : txt.replace(/\(.+\)/, '').trim();
        if(orderStatusSelect) orderStatusSelect.value = status;
        this.filterOrders(status);
      });
    });
    // 订单详情弹窗
    const ordersTable = document.querySelector('#view-orders tbody');
    if (ordersTable) {
      ordersTable.addEventListener('click', (e) => {
        const btn = e.target.closest('button');
        if (!btn) return;
        const row = btn.closest('tr');
        if (!row) return;
        const idx = Array.from(ordersTable.children).indexOf(row);
        const order = this.filteredOrders && this.filteredOrders.length ? this.filteredOrders[idx] : this.currentOrders[idx];
        if (!order) return;
        this.showOrderDetail(order);
      });
    }
    const closeBtn = document.getElementById('order-detail-close');
    if (closeBtn) {
      closeBtn.onclick = () => {
        document.getElementById('order-detail-modal').style.display = 'none';
      };
    }
  }

  filterOrders(status) {
    if (!status || status === '全部状态') {
      this.filteredOrders = null;
      this.updateOrdersTable();
      return;
    }
    const map = {
      '待付款': 'pending', '已付款': 'paid', '配送中': 'shipping', '已完成': 'completed', '已取消': 'cancelled'
    };
    const code = map[status] || status;
    this.filteredOrders = this.currentOrders.filter(o => (o.status || '').toLowerCase().includes(code));
    this.updateOrdersTable();
  }

  showOrderDetail(order) {
    const modal = document.getElementById('order-detail-modal');
    const content = document.getElementById('order-detail-content');
    if (!modal || !content) return;
    // 风格化显示订单信息
    const statusMap = {
      pending: '待付款', paid: '已付款', shipping: '配送中', completed: '已完成', cancelled: '已取消'
    };
    content.innerHTML = `
      <div style="font-size:18px;font-weight:bold;margin-bottom:10px;">订单号：${order.order_number || ''}</div>
      <div style="margin-bottom:8px;">下单时间：${order.created_at ? this.formatDate(order.created_at) : ''}</div>
      <div style="margin-bottom:8px;">用户：${order.username || order.user_id || ''}</div>
      <div style="margin-bottom:8px;">商品：${order.product_info || '-'}</div>
      <div style="margin-bottom:8px;">金额：<span style='color:var(--rose);'>¥${Number(order.total_amount || 0).toFixed(2)}</span></div>
      <div style="margin-bottom:8px;">支付方式：${order.payment_method || '-'}</div>
      <div style="margin-bottom:18px;">状态：
        <select id="order-status-select" style="padding:4px 10px;">
          <option value="pending" ${order.status==='pending'?'selected':''}>待付款</option>
          <option value="paid" ${order.status==='paid'?'selected':''}>已付款</option>
          <option value="shipping" ${order.status==='shipping'?'selected':''}>配送中</option>
          <option value="completed" ${order.status==='completed'?'selected':''}>已完成</option>
          <option value="cancelled" ${order.status==='cancelled'?'selected':''}>已取消</option>
        </select>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:12px;">
        <button id="order-detail-save" class="form-btn">保存</button>
      </div>
    `;
    modal.style.display = 'flex';
    document.getElementById('order-detail-save').onclick = async () => {
      const newStatus = document.getElementById('order-status-select').value;
      await this.updateOrderStatus(order.id, newStatus);
      modal.style.display = 'none';
    };
  }

  exportOrdersToExcel() {
    // 导出当前筛选结果为Excel
    const orders = this.filteredOrders && this.filteredOrders.length ? this.filteredOrders : this.currentOrders;
    if (!orders.length) {
      this.showMessage('无订单可导出', 'error');
      return;
    }
    // 生成表头和数据
    const header = ['订单号','下单时间','用户','商品','金额','支付方式','状态'];
    const rows = orders.map(o => [
      o.order_number || '',
      o.created_at ? this.formatDate(o.created_at) : '',
      o.username || o.user_id || '',
      o.product_info || '-',
      Number(o.total_amount || 0).toFixed(2),
      o.payment_method || '-',
      o.status || ''
    ]);
    let csv = '\uFEFF' + header.join(',') + '\n' + rows.map(r => r.map(x => '"'+String(x).replace(/"/g,'""')+'"').join(',')).join('\n');
    const blob = new Blob([csv], {type: 'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '订单列表.csv';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 0);
    this.showMessage('订单已导出', 'success');
  }

  async updateOrderStatus(id, status) {
    try {
      const response = await fetch(`${this.ordersApi}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      const result = await response.json();
      if (!result.success) throw new Error(result.error || '更新失败');
      this.showMessage('订单状态已更新', 'success');
      await this.loadOrders();
    } catch (_e) {
      this.showMessage('订单状态更新失败', 'error');
    }
  }

  async loadProducts() {
    try {
      const response = await fetch(this.productsApi);
      const result = await response.json();
      this.currentProducts = result.success ? result.data : [];
      // 按id递增排序
      this.currentProducts.sort((a, b) => Number(a.id) - Number(b.id));
    } catch (_e) {
      this.currentProducts = [];
    }
    this.updateProductsTable();
    this.updateInventoryStats();
  }

  async loadOrders() {
    try {
      const response = await fetch(this.ordersApi);
      const result = await response.json();
      this.currentOrders = result.success ? result.data : [];

      // 为每个订单获取订单项数据
      for (const order of this.currentOrders) {
        try {
          const itemsRes = await fetch(`http://localhost:3000/api/order-items?order_number=${order.order_number}`);
          const itemsResult = await itemsRes.json();
          if (itemsResult.success && itemsResult.data) {
            order.items = itemsResult.data;
            order.item_count = itemsResult.data.length;
          }
        } catch (e) {
          console.error('获取订单项失败:', e);
          order.items = [];
          order.item_count = 0;
        }
      }
    } catch (_e) {
      this.currentOrders = [];
    }
    this.updateOrdersTable();
  }

  async loadUsers() {
    try {
      const response = await fetch(this.usersApi);
      const result = await response.json();
      this.currentUsers = result.success ? result.data : [];
    } catch (_e) {
      this.currentUsers = [];
    }
    this.updateUsersTable();
  }

  async loadReviews() {
    try {
      const response = await fetch(this.reviewsApi);
      const result = await response.json();
      console.log('评论数据加载结果:', result);
      this.currentReviews = result.success ? result.data : [];
    } catch (_e) {
      console.error('加载评论失败:', _e);
      this.currentReviews = [];
    }
    this.updateReviewsTable();
  }

  async loadDashboardStats() {
    try {
      const response = await fetch('http://localhost:3000/api/admin/dashboard');
      const result = await response.json();
      console.log('统计数据加载结果:', result);
      if (result.success && result.data) {
        this.updateDashboardCharts(result.data);
      } else {
        console.error('统计数据格式错误:', result);
      }
    } catch (_e) {
      console.error('加载统计数据失败:', _e);
    }
  }

  updateDashboardCharts(data) {
    // 更新近7日销售趋势 - 改为折线图
    const salesTrend = data.sales_trend || [];
    const barChart = document.querySelector('.bar-chart');
    if (barChart) {
      if (salesTrend.length > 0) {
        const maxSales = Math.max(...salesTrend.map(d => d.amount || 0));
        const days = ['周一', '周二', '周三', '周四', '周五', '周六', '周日'];

        // 创建折线图SVG
        const chartWidth = 600;
        const chartHeight = 200;
        const padding = 35;
        const pointSpacing = (chartWidth - padding * 2) / (salesTrend.length - 1);

        const points = salesTrend.map((item, index) => {
          const x = padding + index * pointSpacing;
          const y = chartHeight - padding - (maxSales > 0 ? (item.amount / maxSales) * (chartHeight - padding * 2) : 0);
          return { x, y, amount: item.amount, day: days[index % 7] };
        });

        const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

        barChart.innerHTML = `
          <svg width="100%" height="280" viewBox="0 0 ${chartWidth} ${chartHeight -190}" style="overflow:visible;">
            <!-- 网格线 -->
            <line x1="${padding}" y1="${chartHeight - padding}" x2="${chartWidth - padding + 20}" y2="${chartHeight - padding}" stroke="rgba(214, 214, 214, 0.7)" />
            <line x1="${padding}" y1="${padding}" x2="${padding}" y2="${chartHeight - padding}" stroke="rgba(214, 214, 214, 0.7)" />

            <!-- 折线 -->
            <path d="${pathData}" fill="none" stroke="var(--gold)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />

            <!-- 数据点和标签 -->
            ${points.map(p => `
              <circle cx="${p.x}" cy="${p.y}" r="5" fill="var(--gold)" stroke="var(--panel)" stroke-width="2" />
              <text x="${p.x}" y="${p.y - 15}" text-anchor="middle" fill="var(--gold)" font-size="12">${this.formatNumber(p.amount)}</text>
              <text x="${p.x}" y="${chartHeight - padding + 25}" text-anchor="middle" fill="var(--silver)" font-size="12">${p.day}</text>
            `).join('')}
          </svg>
        `;
      } else {
        barChart.innerHTML = '<div style="padding:40px;text-align:center;color:var(--muted);">暂无销售数据</div>';
      }
    }

    // 更新风格销售占比
    const styleSales = data.style_sales || {};
    // 按销量排序，只显示前5个分类
    const sortedStyles = Object.entries(styleSales)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    const totalSales = sortedStyles.reduce((sum, [_, count]) => sum + (count || 0), 0);
    const donutNum = document.querySelector('.donut-num');
    if (donutNum) {
      donutNum.textContent = this.formatNumber(totalSales);
    }

    const donutLegend = document.querySelector('.donut-legend');
    if (donutLegend) {
      const colors = ['var(--blood)', 'rgba(139,26,26,.4)', 'var(--gold)', 'rgba(201,168,76,.3)', 'var(--blue)', 'var(--muted)'];
      if (sortedStyles.length > 0) {
        donutLegend.innerHTML = sortedStyles.map(([style, count], index) => {
          const percentage = totalSales > 0 ? Math.round((count / totalSales) * 100) : 0;
          const color = colors[index % colors.length];
          return `
            <div class="legend-item">
              <div class="legend-dot" style="background:${color}"></div>
              ${style}
              <div class="legend-pct">${count}件 (${percentage}%)</div>
            </div>
          `;
        }).join('');
      } else {
        donutLegend.innerHTML = '<div style="color:var(--muted);padding:20px;text-align:center;">暂无风格数据</div>';
      }
    }
  }

  updateRecentOrders(orders) {
    const tbody = document.querySelector('#view-dashboard .data-table tbody');
    if (!tbody) return;
    if (!orders.length) {
      tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--muted);">暂无订单</td></tr>';
      return;
    }
    tbody.innerHTML = orders.slice(0, 5).map(order => {
      const statusMap = {
        pending: '待付款',
        paid: '已付款',
        shipping: '配送中',
        completed: '已完成',
        cancelled: '已取消'
      };
      const statusClass = {
        pending: 'status-pending',
        paid: 'status-paid',
        shipping: 'status-ship',
        completed: 'status-paid',
        cancelled: 'status-cancel'
      };
      const status = statusMap[order.status] || order.status;
      const statusBadge = `<span class="status-badge ${statusClass[order.status] || 'status-pending'}">${status}</span>`;
      return `
        <tr>
          <td style="font-family:'JetBrains Mono',monospace;font-size:11px;">#${order.order_number || ''}</td>
          <td>${order.username || order.user_id || '-'}</td>
          <td style="color:var(--rose);">¥ ${Number(order.total_amount || 0).toFixed(2)}</td>
          <td>${statusBadge}</td>
        </tr>
      `;
    }).join('');
  }

  updateRecentActivities(activities) {
    const activityList = document.querySelector('.activity-list');
    if (!activityList) return;
    if (!activities.length) {
      activityList.innerHTML = '<div style="color:var(--muted);padding:20px;text-align:center;">暂无动态</div>';
      return;
    }
    const dotColors = {
      'order': 'act-green',
      'stock': 'act-gold',
      'user': 'act-blue',
      'refund': 'act-red',
      'review': 'act-gold',
      'product': 'act-green'
    };
    activityList.innerHTML = activities.slice(0, 6).map(activity => {
      const dotClass = dotColors[activity.type] || 'act-gold';
      return `
        <div class="activity-item">
          <div class="act-dot ${dotClass}"></div>
          <div>
            <div class="act-text">${activity.message || '-'}</div>
            <div class="act-time">${this.formatTimeAgo(activity.created_at)}</div>
          </div>
        </div>
      `;
    }).join('');
  }

  formatNumber(num) {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'k';
    }
    return num.toString();
  }

  formatTimeAgo(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    if (diff < 60) return diff + ' 分钟前';
    if (diff < 3600) return Math.floor(diff / 60) + ' 小时前';
    if (diff < 86400) return Math.floor(diff / 3600) + ' 天前';
    return this.formatDate(dateStr);
  }

  async loadCategories() {
    try {
      const response = await fetch('http://localhost:3000/api/categories');
      const result = await response.json();
      if (result.success) this.updateCategorySelects(result.data || []);
    } catch (_e) {
      this.updateCategorySelects([]);
    }
  }

  updateProductsTable() {
    const tbody = document.querySelector('#view-products tbody');
    if (!tbody) return;
    tbody.innerHTML = '';

    // 使用搜索结果或当前商品列表
    const products = this.filteredProducts && this.filteredProducts.length ? this.filteredProducts : this.currentProducts;

    // 过滤掉已下架的商品
    const activeProducts = products.filter(product => (product.status || 'active') === 'active');

    if (!activeProducts.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--muted);">暂无商品</td></tr>';
      return;
    }

    activeProducts.forEach((product) => {
      const style = product.style || product.category || '-';
      const price = Number(product.price || 0).toFixed(2);
      const stock = Number(product.stock || 0);
      const isActive = (product.status || 'active') === 'active';
      const row = document.createElement('tr');
      row.innerHTML = `
        <td><div class="prod-thumb">${this.getProductIcon(style)}</div></td>
        <td>${product.name || ''}</td>
        <td style="color:var(--gold);font-size:11px;">${style}</td>
        <td style="color:var(--rose);">¥ ${price}</td>
        <td>${this.createStockBar(stock)}</td>
        <td style="color:var(--muted);">${product.sales || 0}</td>
        <td>${this.createStatusBadge(product.status)}</td>
        <td style="display:flex;gap:6px;">
          <button class="tbl-btn" data-action="edit" data-id="${product.id}">编辑</button>
          <button class="tbl-btn" data-action="stock" data-id="${product.id}">补货</button>
          <button class="tbl-btn tbl-btn-del" data-action="toggle" data-id="${product.id}">${isActive ? '下架' : '上架'}</button>
        </td>
      `;
      tbody.appendChild(row);
    });
  }

  updateOrdersTable() {
    const tbody = document.querySelector('#view-orders tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    const orders = this.filteredOrders && this.filteredOrders.length ? this.filteredOrders : this.currentOrders;
    if (!orders.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--muted);">暂无订单</td></tr>';
      return;
    }
    orders.forEach((order) => {
      const items = order.items || [];
      const productSummary = items.length
        ? items.map((it) => `${it.product_name || '商品'} ×${it.quantity || 1}`).join('<br>')
        : (order.product_info || '-');
      const itemCount = order.item_count || items.length || 1;
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${order.order_number || ''}</td>
        <td style="color:var(--muted);font-size:11px;">${this.formatDate(order.created_at)}</td>
        <td>${order.username || order.user_id || ''}</td>
        <td style="line-height:1.6;">${productSummary}</td>
        <td style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--gold);">${itemCount}</td>
        <td style="color:var(--rose);">¥ ${Number(order.total_amount || 0).toFixed(2)}</td>
        <td style="color:var(--muted);font-size:11px;">${order.payment_method || '-'}</td>
        <td><span class="status-badge status-paid">${order.status || 'pending'}</span></td>
        <td><button class="tbl-btn">详情</button></td>
      `;
      tbody.appendChild(row);
    });
  }

  updateUsersTable() {
    const tbody = document.querySelector('#view-users tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    const users = this.filteredUsers && this.filteredUsers.length ? this.filteredUsers : this.currentUsers;
    if (!users.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--muted);">暂无用户</td></tr>';
      return;
    }
    users.forEach((user, idx) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${user.username || ''}</td>
        <td style="font-family:'JetBrains Mono',monospace;font-size:11px;color:var(--muted);">${user.phone || '-'}</td>
        <td style="color:var(--muted);font-size:11px;">${this.formatDate(user.created_at)}</td>
        <td>${user.member_level || '普通'}</td>
        <td style="color:var(--rose);">¥ ${Number(user.total_spent || 0).toFixed(2)}</td>
        <td style="font-family:'JetBrains Mono',monospace;">${user.points || 0}</td>
        <td><span class="status-badge status-paid">${user.status || 'active'}</span></td>
        <td><button class="tbl-btn" data-idx="${idx}">详情</button></td>
      `;
      tbody.appendChild(row);
    });
    tbody.addEventListener('click', (e) => {
      const btn = e.target.closest('button.tbl-btn');
      if (!btn) return;
      const idx = btn.dataset.idx;
      const user = users[idx];
      if (!user) return;
      this.showUserDetail(user);
    });
  }

  updateReviewsTable() {
    const tbody = document.querySelector('#view-reviews tbody');
    if (!tbody) {
      console.error('找不到评论表格tbody');
      return;
    }
    tbody.innerHTML = '';
    const reviews = this.filteredReviews && this.filteredReviews.length ? this.filteredReviews : this.currentReviews;
    console.log('当前评论数据:', reviews);
    if (!reviews.length) {
      tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--muted);">暂无评论</td></tr>';
      return;
    }
    reviews.forEach((review, idx) => {
      const rating = Number(review.rating) || 0;
      const ratingStars = '★'.repeat(rating) + '☆'.repeat(5 - rating);
      const userName = review.user_name || (review.user_id ? `用户${review.user_id}` : '匿名');
      const productName = review.product_name || (review.product_id ? `商品#${review.product_id}` : '-');
      const orderId = review.order_id ? `#${review.order_id}` : '-';
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${userName}</td>
        <td>${productName}</td>
        <td style="color:var(--muted);font-size:11px;">${orderId}</td>
        <td style="color:var(--gold);">${ratingStars}</td>
        <td style="max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${(review.content || '').replace(/"/g, '&quot;')}">${review.content || '-'}</td>
        <td style="color:var(--muted);font-size:11px;">${this.formatDate(review.created_at)}</td>
        <td><button class="tbl-btn tbl-btn-del" data-action="delete-review" data-id="${review.id}">删除</button></td>
      `;
      tbody.appendChild(row);
    });
  }

  showUserDetail(user) {
    const modal = document.getElementById('user-detail-modal');
    const content = document.getElementById('user-detail-content');
    if (!modal || !content) return;
    content.innerHTML = `
      <div style="font-size:18px;font-weight:bold;margin-bottom:10px;">用户ID：${user.id || ''}</div>
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label">用户名</label>
        <input class="form-input" type="text" id="ud-username" value="${user.username||''}" />
      </div>
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label">手机号</label>
        <input class="form-input" type="text" id="ud-phone" value="${user.phone||''}" />
      </div>
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label">会员等级</label>
        <input class="form-input" type="text" id="ud-member" value="${user.member_level||''}" />
      </div>
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label">累计消费</label>
        <input class="form-input" type="number" id="ud-spent" value="${user.total_spent||0}" />
      </div>
      <div class="form-group" style="margin-bottom:10px;">
        <label class="form-label">积分</label>
        <input class="form-input" type="number" id="ud-points" value="${user.points||0}" />
      </div>
      <div class="form-group" style="margin-bottom:18px;">
        <label class="form-label">状态</label>
        <select id="ud-status" class="form-input">
          <option value="active" ${user.status==='active'?'selected':''}>正常</option>
          <option value="banned" ${user.status==='banned'?'selected':''}>封禁</option>
        </select>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:12px;">
        <button id="user-detail-save" class="form-btn">保存</button>
      </div>
    `;
    modal.style.display = 'flex';
    document.getElementById('user-detail-close').onclick = () => {
      modal.style.display = 'none';
    };
    document.getElementById('user-detail-save').onclick = async () => {
      const data = {
        username: document.getElementById('ud-username').value.trim(),
        phone: document.getElementById('ud-phone').value.trim(),
        member_level: document.getElementById('ud-member').value.trim(),
        total_spent: Number(document.getElementById('ud-spent').value),
        points: Number(document.getElementById('ud-points').value),
        status: document.getElementById('ud-status').value
      };
      await this.updateUser(user.id, data);
      modal.style.display = 'none';
    };
  }

  async updateUser(id, data) {
    try {
      const response = await fetch(`${this.usersApi}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (!result.success) throw new Error(result.error || '更新失败');
      this.showMessage('用户信息已更新', 'success');
      await this.loadUsers();
    } catch (_e) {
      this.showMessage('用户信息更新失败', 'error');
    }
  }

  updateCategorySelects(categories) {
    const styleSelect = document.querySelector('#view-add-product .form-row .form-select');
    if (!styleSelect) return;
    if (!categories.length) return;
    styleSelect.innerHTML = categories.map((c) => `<option>${c}</option>`).join('');
  }

  updateInventoryStats() {
    const stats = { sufficient: 0, warning: 0, low: 0, out: 0 };
    this.currentProducts.forEach((p) => {
      const stock = Number(p.stock || 0);
      if (stock === 0) stats.out += 1;
      else if (stock < 5) stats.low += 1;
      else if (stock < 20) stats.warning += 1;
      else stats.sufficient += 1;
    });
    const values = document.querySelectorAll('#view-inventory .stat-value');
    if (values.length >= 4) {
      values[0].textContent = stats.sufficient;
      values[1].textContent = stats.warning;
      values[2].textContent = stats.low;
      values[3].textContent = stats.out;
    }
  }

  collectFormData() {
    const form = document.querySelector('#view-add-product');
    if (!form) return null;
    const selects = form.querySelectorAll('.form-select');
    return {
      name: form.querySelector('input[placeholder="请输入商品名称"]')?.value?.trim() || '',
      style: selects[0]?.value || '',
      category: selects[1]?.value || '',
      description: form.querySelector('textarea[placeholder="请输入详细商品描述..."]')?.value?.trim() || '',
      price: Number(form.querySelector('input[placeholder="0.00"]')?.value || 0),
      original_price: Number(form.querySelector('input[placeholder="0.00（可选）"]')?.value || 0) || null,
      stock: Number(form.querySelector('input[placeholder="0"]')?.value || 0),
      brand: form.querySelector('input[placeholder="品牌名称"]')?.value?.trim() || '',
      sizes: form.querySelector('input[placeholder="S, M, L, XL, 均码"]')?.value?.trim() || '',
      colors: form.querySelector('input[placeholder="黑色, 深红, 暗紫"]')?.value?.trim() || '',
      seo_keywords: form.querySelector('input[placeholder="哥特 蕾丝 黑裙..."]')?.value?.trim() || '',
      seo_description: form.querySelector('textarea[placeholder="用于搜索结果展示的简短描述..."]')?.value?.trim() || '',
      image_url: form.querySelector('#product-image-url')?.value?.trim() || '',
      status: 'active',
    };
  }

  validateFormData(data) {
    return !!(data && data.name && data.price > 0);
  }

  clearForm() {
    const form = document.querySelector('#view-add-product');
    if (!form) return;
    form.querySelectorAll('.form-input').forEach((i) => (i.value = ''));
    form.querySelectorAll('.form-select').forEach((s) => {
      s.selectedIndex = 0;
    });
    const fileInput = document.getElementById('product-image-file');
    if (fileInput) fileInput.value = '';
    const preview = document.getElementById('product-image-preview');
    if (preview) { preview.src = ''; preview.style.display = 'none'; }
    const current = document.getElementById('product-image-current');
    if (current) current.style.display = 'none';
    this.editingProductId = null;
    const btn = form.querySelector('.form-btn');
    if (btn) btn.textContent = '发布商品';
  }

  async handleAddProduct() {
    const formData = this.collectFormData();
    if (!this.validateFormData(formData)) {
      this.showMessage('请填写商品名称和售价', 'error');
      return;
    }
    // 获取下一个商品ID
    try {
      const response = await fetch('http://localhost:3000/api/products/next-id');
      const result = await response.json();
      if (result.success && result.next_id) {
        formData.next_id = result.next_id;
      }
    } catch (e) {
      console.error('获取下一个商品ID失败:', e);
    }
    if (this.editingProductId) {
      await this.updateProduct(this.editingProductId, formData);
      return;
    }
    await this.addProduct(formData);
  }

  async addProduct(data) {
    try {
      console.log('开始添加商品，数据:', data);
      const response = await fetch(this.productsApi, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const result = await response.json();
      console.log('添加商品响应:', result);
      if (!result.success) throw new Error(result.error || '新增失败');
      const newId = data.next_id || result.id;
      console.log('新商品ID:', newId);
      if (this.getImageFile()) {
        await this.uploadProductImage(newId);
      }
      this.showMessage('商品添加成功', 'success');
      this.clearForm();
      await this.loadProducts();
      switchView('products');
    } catch (_e) {
      console.error('添加商品失败:', _e);
      this.showMessage('商品添加失败: ' + (_e.message || '未知错误'), 'error');
    }
  }

  async updateProduct(id, data) {
    try {
      const response = await fetch(`${this.productsApi}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      const result = await response.json();
      if (!result.success) throw new Error(result.error || '更新失败');
      if (this.getImageFile()) {
        await this.uploadProductImage(id);
      }
      this.showMessage('商品更新成功', 'success');
      this.clearForm();
      await this.loadProducts();
      switchView('products');
    } catch (_e) {
      this.showMessage('商品更新失败', 'error');
    }
  }

  getImageFile() {
    const input = document.getElementById('product-image-file');
    return input && input.files && input.files.length > 0 ? input.files[0] : null;
  }

  async uploadProductImage(productId) {
    const file = this.getImageFile();
    if (!file) return null;
    const fd = new FormData();
    fd.append('image', file);
    const response = await fetch(`http://localhost:3000/api/upload/${productId}`, {
      method: 'POST',
      body: fd,
    });
    const result = await response.json();
    if (!result.success) throw new Error(result.error || '图片上传失败');
    return result.image_url;
  }

  async deleteProduct(id) {
    try {
      const response = await fetch(`${this.productsApi}/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (!result.success) throw new Error(result.error || '删除失败');
      this.showMessage('商品删除成功', 'success');
      await this.loadProducts();
    } catch (_e) {
      this.showMessage('商品删除失败', 'error');
    }
  }

  async deleteReview(id) {
    try {
      const response = await fetch(`${this.reviewsApi}/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (!result.success) throw new Error(result.error || '删除失败');
      this.showMessage('评论删除成功', 'success');
      await this.loadReviews();
    } catch (_e) {
      this.showMessage('评论删除失败', 'error');
    }
  }

  editProduct(id) {
    const product = this.currentProducts.find((p) => Number(p.id) === Number(id));
    if (!product) return;
    this.editingProductId = product.id;
    switchView('add-product');

    const form = document.querySelector('#view-add-product');
    if (!form) return;
    const selects = form.querySelectorAll('.form-select');
    // 填充商品ID
    const productIdInput = document.getElementById('product-id');
    if (productIdInput) productIdInput.value = product.id || '';
    form.querySelector('input[placeholder="请输入商品名称"]').value = product.name || '';
    if (selects[0]) selects[0].value = product.style || product.category || selects[0].value;
    if (selects[1]) selects[1].value = product.category || selects[1].value;
    form.querySelector('textarea[placeholder="请输入详细商品描述..."]').value = product.description || '';
    form.querySelector('input[placeholder="0.00"]').value = product.price || '';
    const originalPriceInput = form.querySelector('input[placeholder="0.00（可选）"]');
    if (originalPriceInput) originalPriceInput.value = product.original_price || '';
    form.querySelector('input[placeholder="0"]').value = product.stock || 0;
    form.querySelector('input[placeholder="品牌名称"]').value = product.brand || '';
    form.querySelector('input[placeholder="S, M, L, XL, 均码"]').value = product.sizes || '';
    const colorsInput = form.querySelector('input[placeholder="黑色, 深红, 暗紫"]');
    if (colorsInput) colorsInput.value = product.colors || '';
    const seoKeywordsInput = form.querySelector('input[placeholder="哥特 蕾丝 黑裙..."]');
    if (seoKeywordsInput) seoKeywordsInput.value = product.seo_keywords || '';
    const seoDescInput = form.querySelector('textarea[placeholder="用于搜索结果展示的简短描述..."]');
    if (seoDescInput) seoDescInput.value = product.seo_description || '';

    const fileInput = document.getElementById('product-image-file');
    if (fileInput) fileInput.value = '';
    const preview = document.getElementById('product-image-preview');
    const currentDiv = document.getElementById('product-image-current');
    if (product.image_url) {
      if (preview) {
        preview.src = product.image_url;
        preview.style.display = '';
      }
      if (currentDiv) {
        document.getElementById('current-image-path').textContent = product.image_url;
        currentDiv.style.display = '';
      }
    } else {
      if (preview) { preview.src = ''; preview.style.display = 'none'; }
      if (currentDiv) currentDiv.style.display = 'none';
    }

    const btn = form.querySelector('.form-btn');
    if (btn) btn.textContent = '更新商品';
  }

  async toggleProductStatus(id) {
    const product = this.currentProducts.find((p) => Number(p.id) === Number(id));
    if (!product) return;
    // 改为删除操作而不是切换状态
    await this.deleteProduct(id);
  }

  async deleteProduct(id) {
    try {
      const response = await fetch(`${this.productsApi}/${id}`, { method: 'DELETE' });
      const result = await response.json();
      if (!result.success) throw new Error(result.error || '删除失败');
      this.showMessage('商品删除成功', 'success');
      await this.loadProducts();
    } catch (_e) {
      this.showMessage('商品删除失败', 'error');
    }
  }

  showStockModal(id) {
    const product = this.currentProducts.find((p) => Number(p.id) === Number(id));
    if (!product) return;
    const nextStock = prompt(`请输入 "${product.name}" 的新库存数量`, product.stock || 0);
    if (nextStock === null) return;
    const num = Number(nextStock);
    if (Number.isNaN(num) || num < 0) {
      this.showMessage('库存请输入非负数字', 'error');
      return;
    }
    this.updateProduct(id, { stock: num });
  }

  createStockBar(stock) {
    const max = 100;
    const percentage = Math.max(0, Math.min((stock / max) * 100, 100));
    const statusClass = stock === 0 ? 's-out' : stock < 20 ? 's-low' : 's-ok';
    return `
      <div class="stock-bar-wrap">
        <div class="stock-bar"><div class="stock-fill ${statusClass}" style="width:${percentage}%"></div></div>
        <div class="stock-num">${stock}</div>
      </div>
    `;
  }

  createStatusBadge(status) {
    const map = {
      active: '<span class="status-badge status-paid">上架中</span>',
      inactive: '<span class="status-badge status-cancel">已下架</span>',
      low_stock: '<span class="status-badge status-pending">库存紧张</span>',
    };
    return map[status] || map.active;
  }

  getProductIcon(style) {
    const icons = {
      哥特暗黑: '🕸️',
      洛丽塔: '🎀',
      朋克: '⛓️',
      原宿: '🌸',
      赛博朋克: '🤖',
      女装: '👗',
      配饰: '💍',
    };
    return icons[style] || '👗';
  }

  formatDate(input) {
    if (!input) return '-';
    const d = new Date(input);
    if (Number.isNaN(d.getTime())) return String(input);
    return d.toISOString().slice(0, 19).replace('T', ' ');
  }

  showMessage(message, type = 'info') {
    const toast = document.createElement('div');
    toast.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 12px 20px;
      background: ${type === 'success' ? 'var(--green)' : type === 'error' ? 'var(--rose)' : 'var(--blue)'};
      color: white;
      border-radius: 4px;
      font-size: 12px;
      z-index: 1000;
      opacity: 0;
      transition: opacity 0.3s;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '1';
    }, 30);
    setTimeout(() => {
      toast.style.opacity = '0';
      setTimeout(() => {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, 2200);
  }
}

async function loadSystemSettings() {
  const fields = document.getElementById('system-settings-fields');
  if (!fields) return;

  try {
    const res = await fetch('http://localhost:3000/api/system-info');
    const data = (await res.json()).data || {};
    const keys = Object.keys(data);

    fields.innerHTML = '';
    if (!keys.length) {
      fields.innerHTML = '<div style="color:var(--muted);">暂无系统设置数据</div>';
      return;
    }

    keys.forEach((key) => {
      fields.innerHTML += `<div class="form-group"><label class="form-label">${key}</label><input class="form-input" name="${key}" value="${data[key] || ''}" /></div>`;
    });
  } catch (_e) {
    fields.innerHTML = '<div style="color:var(--rose);">系统设置加载失败，请检查后端服务</div>';
  }
}

async function saveSystemSettings() {
  const form = document.getElementById('system-settings-form');
  if (!form) return;
  const inputs = form.querySelectorAll('input.form-input');
  const data = {};
  inputs.forEach(input => {
    data[input.name] = input.value;
  });
  try {
    const res = await fetch('http://localhost:3000/api/system-info', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await res.json();
    if (!result.success) throw new Error();
    alert('保存成功');
  } catch (_e) {
    alert('保存失败，请检查后端服务');
  }
}

function bindSystemSettingsEvents() {
  const saveBtn = document.getElementById('system-settings-save');
  if (saveBtn) {
    saveBtn.addEventListener('click', saveSystemSettings);
  }

  const settingsView = document.getElementById('view-settings');
  if (settingsView && settingsView.classList.contains('active')) {
    loadSystemSettings();
  }
}

window.loadSystemSettings = loadSystemSettings;
window.saveSystemSettings = saveSystemSettings;

let productManager;
document.addEventListener('DOMContentLoaded', () => {
  productManager = new ProductManager();
  window.productManager = productManager;
  window.adminFunctions = productManager;
  productManager.init();
  bindSystemSettingsEvents();
});

-- 创建数据库
CREATE DATABASE IF NOT EXISTS INFINATE DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
USE INFINATE;

-- 用户表
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(32) NOT NULL UNIQUE,
  password VARCHAR(128) NOT NULL,
  email VARCHAR(64),
  phone VARCHAR(32),
  address VARCHAR(255),
  member_level VARCHAR(16) DEFAULT '普通',
  avatar_url VARCHAR(255),
  status VARCHAR(16) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 用户信息表
CREATE TABLE user_info (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  real_name VARCHAR(32),
  address VARCHAR(255),
  contact VARCHAR(64),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 管理员表
CREATE TABLE admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(32) NOT NULL UNIQUE,
  password VARCHAR(128) NOT NULL,
  email VARCHAR(64),
  status VARCHAR(16) DEFAULT 'active'
);

-- 商品信息表
CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(64) NOT NULL,
  stock INT NOT NULL DEFAULT 0,
  price DECIMAL(10,2) NOT NULL,
  category VARCHAR(32),
  brand VARCHAR(32),
  image_url VARCHAR(255),
  description TEXT,
  status VARCHAR(16) DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 收藏表
CREATE TABLE favorites (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 购物车表
CREATE TABLE cart (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 订单表
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_number VARCHAR(32) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  contact VARCHAR(64),
  address VARCHAR(255),
  total_amount DECIMAL(10,2) NOT NULL,
  status VARCHAR(16) DEFAULT 'pending',
  payment_method VARCHAR(32),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 订单商品明细表
CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);

-- 评价表
CREATE TABLE reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  product_id INT NOT NULL,
  order_id INT,
  content TEXT,
  rating INT CHECK(rating BETWEEN 1 AND 5),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE SET NULL
);

-- 系统信息表
CREATE TABLE system_info (
  id INT AUTO_INCREMENT PRIMARY KEY,
  key_name VARCHAR(64) NOT NULL UNIQUE,
  value TEXT
);

-- 物流信息表
CREATE TABLE logistics (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  tracking_number VARCHAR(64),
  company VARCHAR(32),
  status VARCHAR(32),
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
);

-- 商品数据
INSERT INTO products (name, stock, price, category, brand, image_url, description) VALUES
('哥特蕾丝连衣裙', 9, 688.00, '哥特暗黑', 'DarkMoon', '/pic/gothic1.jpg', '暗黑哥特风蕾丝裙'),
('朋克链条外套', 28, 1280.00, '朋克', 'PunkStar', '/pic/punk1.jpg', '朋克风链条皮外套'),
('洛丽塔泡泡袖', 48, 520.00, '洛丽塔', 'LolitaDream', '/pic/lolita1.jpg', '甜美洛丽塔泡泡袖'),
('视觉系夹克', 18, 980.00, '视觉系', 'VisualStorm', '/pic/vkei1.jpg', '视觉系拼接夹克'),
('赛博荧光机能裤', 58, 580.00, '赛博朋克', 'NeonCircuit', '/pic/cyber1.jpg', '荧光反光科技裤'),
('哥特玫瑰丝绒礼服裙', 2, 1580.00, '哥特暗黑', 'DarkRose', '/pic/gothic2.jpg', '玫瑰丝绒礼服'),
('甜系Lolita泡泡袖洋装', 48, 520.00, '洛丽塔', 'LolitaDream', '/pic/lolita2.jpg', '甜美泡泡袖洋装'),
('朋克皮夹克', 15, 1280.00, '朋克', 'PunkStar', '/pic/punk2.jpg', '朋克风皮夹克'),
('原宿宽松卫衣', 30, 320.00, '原宿', 'Harajuku', '/pic/harajuku1.jpg', '原宿风宽松卫衣'),
('暗黑蜘蛛网蕾丝连衣裙', 9, 688.00, '哥特暗黑', 'DarkMoon', '/pic/gothic3.jpg', '蜘蛛网蕾丝裙'),
('水晶刺绣上衣', 22, 360.00, '哥特暗黑', 'CrystalNight', '/pic/gothic4.jpg', '水晶刺绣上衣'),
('朋克铆钉裙', 12, 890.00, '朋克', 'PunkStar', '/pic/punk3.jpg', '朋克铆钉短裙'),
('赛博朋克风夹克', 16, 1180.00, '赛博朋克', 'NeonCircuit', '/pic/cyber2.jpg', '赛博朋克夹克'),
('哥特长靴', 21, 980.00, '哥特暗黑', 'DarkMoon', '/pic/gothic5.jpg', '哥特高筒靴'),
('甜系Lolita花边袜', 60, 80.00, '洛丽塔', 'LolitaDream', '/pic/lolita3.jpg', '花边袜'),
('原宿印花T恤', 44, 180.00, '原宿', 'Harajuku', '/pic/harajuku2.jpg', '印花T恤'),
('视觉系金属项链', 35, 120.00, '视觉系', 'VisualStorm', '/pic/vkei2.jpg', '金属项链'),
('朋克风牛仔裤', 25, 390.00, '朋克', 'PunkStar', '/pic/punk4.jpg', '朋克牛仔裤'),
('哥特暗黑披风', 7, 880.00, '哥特暗黑', 'DarkMoon', '/pic/gothic6.jpg', '暗黑披风'),
('赛博朋克运动鞋', 18, 680.00, '赛博朋克', 'NeonCircuit', '/pic/cyber3.jpg', '运动鞋');

-- 用户数据
INSERT INTO users (username, password, email, phone, address, member_level, avatar_url) VALUES
('alice', 'hash1', 'alice@example.com', '13800000001', '上海市徐汇区1号', 'Gold', '/avatar/a1.png'),
('bob', 'hash2', 'bob@example.com', '13800000002', '上海市浦东新区2号', 'Silver', '/avatar/b2.png'),
('cathy', 'hash3', 'cathy@example.com', '13800000003', '北京朝阳区3号', '普通', '/avatar/c3.png'),
('daniel', 'hash4', 'daniel@example.com', '13800000004', '广州天河区4号', '普通', '/avatar/d4.png'),
('eva', 'hash5', 'eva@example.com', '13800000005', '深圳南山区5号', 'Gold', '/avatar/e5.png'),
('frank', 'hash6', 'frank@example.com', '13800000006', '杭州西湖区6号', 'Silver', '/avatar/f6.png'),
('grace', 'hash7', 'grace@example.com', '13800000007', '南京鼓楼区7号', '普通', '/avatar/g7.png'),
('henry', 'hash8', 'henry@example.com', '13800000008', '成都锦江区8号', 'Gold', '/avatar/h8.png'),
('ivy', 'hash9', 'ivy@example.com', '13800000009', '苏州工业园区9号', '普通', '/avatar/i9.png'),
('jack', 'hash10', 'jack@example.com', '13800000010', '重庆渝中区10号', '普通', '/avatar/j10.png'),
('karen', 'hash11', 'karen@example.com', '13800000011', '武汉武昌区11号', 'Silver', '/avatar/k11.png'),
('leo', 'hash12', 'leo@example.com', '13800000012', '西安雁塔区12号', 'Gold', '/avatar/l12.png'),
('mia', 'hash13', 'mia@example.com', '13800000013', '长沙岳麓区13号', '普通', '/avatar/m13.png'),
('nick', 'hash14', 'nick@example.com', '13800000014', '郑州金水区14号', '普通', '/avatar/n14.png'),
('olivia', 'hash15', 'olivia@example.com', '13800000015', '青岛市南区15号', 'Gold', '/avatar/o15.png'),
('peter', 'hash16', 'peter@example.com', '13800000016', '合肥包河区16号', '普通', '/avatar/p16.png'),
('queen', 'hash17', 'queen@example.com', '13800000017', '厦门思明区17号', 'Silver', '/avatar/q17.png'),
('ray', 'hash18', 'ray@example.com', '13800000018', '天津和平区18号', 'Gold', '/avatar/r18.png'),
('susan', 'hash19', 'susan@example.com', '13800000019', '济南历下区19号', '普通', '/avatar/s19.png'),
('tom', 'hash20', 'tom@example.com', '13800000020', '大连中山区20号', '普通', '/avatar/t20.png');

-- 用户信息数据
INSERT INTO user_info (user_id, real_name, address, contact) VALUES
(1, 'Alice Zhang', '上海市徐汇区1号', '13800000001'),
(2, 'Bob Li', '上海市浦东新区2号', '13800000002'),
(3, 'Cathy Wang', '北京朝阳区3号', '13800000003'),
(4, 'Daniel Wu', '广州天河区4号', '13800000004'),
(5, 'Eva Chen', '深圳南山区5号', '13800000005'),
(6, 'Frank Zhao', '杭州西湖区6号', '13800000006'),
(7, 'Grace Sun', '南京鼓楼区7号', '13800000007'),
(8, 'Henry Ma', '成都锦江区8号', '13800000008'),
(9, 'Ivy Qian', '苏州工业园区9号', '13800000009'),
(10, 'Jack Yu', '重庆渝中区10号', '13800000010'),
(11, 'Karen Du', '武汉武昌区11号', '13800000011'),
(12, 'Leo Jin', '西安雁塔区12号', '13800000012'),
(13, 'Mia Xu', '长沙岳麓区13号', '13800000013'),
(14, 'Nick He', '郑州金水区14号', '13800000014'),
(15, 'Olivia Lin', '青岛市南区15号', '13800000015'),
(16, 'Peter Gao', '合肥包河区16号', '13800000016'),
(17, 'Queen Fang', '厦门思明区17号', '13800000017'),
(18, 'Ray Shi', '天津和平区18号', '13800000018'),
(19, 'Susan Wu', '济南历下区19号', '13800000019'),
(20, 'Tom Wang', '大连中山区20号', '13800000020');

-- 订单数据
INSERT INTO orders (order_number, user_id, contact, address, total_amount, status, payment_method) VALUES
('ORD20240001', 1, 'alice', '上海市徐汇区1号', 688.00, 'paid', '微信支付'),
('ORD20240002', 2, 'bob', '上海市浦东新区2号', 1280.00, 'paid', '支付宝'),
('ORD20240003', 3, 'cathy', '北京朝阳区3号', 520.00, 'pending', '微信支付'),
('ORD20240004', 4, 'daniel', '广州天河区4号', 980.00, 'paid', '银联'),
('ORD20240005', 5, 'eva', '深圳南山区5号', 580.00, 'shipped', '微信支付'),
('ORD20240006', 6, 'frank', '杭州西湖区6号', 1580.00, 'paid', '支付宝'),
('ORD20240007', 7, 'grace', '南京鼓楼区7号', 520.00, 'pending', '微信支付'),
('ORD20240008', 8, 'henry', '成都锦江区8号', 1280.00, 'paid', '微信支付'),
('ORD20240009', 9, 'ivy', '苏州工业园区9号', 320.00, 'paid', '支付宝'),
('ORD20240010', 10, 'jack', '重庆渝中区10号', 688.00, 'cancelled', '微信支付'),
('ORD20240011', 11, 'karen', '武汉武昌区11号', 360.00, 'paid', '银联'),
('ORD20240012', 12, 'leo', '西安雁塔区12号', 890.00, 'pending', '微信支付'),
('ORD20240013', 13, 'mia', '长沙岳麓区13号', 1180.00, 'paid', '支付宝'),
('ORD20240014', 14, 'nick', '郑州金水区14号', 980.00, 'shipped', '微信支付'),
('ORD20240015', 15, 'olivia', '青岛市南区15号', 80.00, 'paid', '微信支付'),
('ORD20240016', 16, 'peter', '合肥包河区16号', 180.00, 'pending', '支付宝'),
('ORD20240017', 17, 'queen', '厦门思明区17号', 120.00, 'paid', '微信支付'),
('ORD20240018', 18, 'ray', '天津和平区18号', 390.00, 'paid', '银联'),
('ORD20240019', 19, 'susan', '济南历下区19号', 880.00, 'shipped', '微信支付'),
('ORD20240020', 20, 'tom', '大连中山区20号', 680.00, 'paid', '支付宝');

-- 订单商品明细
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 1, 688.00), (1, 2, 1, 1280.00),
(2, 3, 2, 520.00), (2, 4, 1, 980.00),
(3, 5, 1, 580.00), (3, 6, 1, 1580.00),
(4, 7, 1, 520.00), (4, 8, 1, 1280.00),
(5, 9, 2, 320.00), (5, 10, 1, 688.00),
(6, 11, 1, 360.00), (6, 12, 1, 890.00),
(7, 13, 1, 1180.00), (7, 14, 1, 980.00),
(8, 15, 1, 80.00), (8, 16, 2, 180.00),
(9, 17, 1, 120.00), (9, 18, 1, 390.00),
(10, 19, 1, 880.00), (10, 20, 1, 680.00);

-- 评价数据
INSERT INTO reviews (user_id, product_id, order_id, content, rating) VALUES
(1, 1, 1, '质量很好，穿着很有气质', 5),
(2, 2, 2, '朋克外套很酷，细节到位', 4),
(3, 3, 3, '泡泡袖很甜美，女朋友很喜欢', 5),
(4, 4, 4, '夹克版型不错，推荐', 4),
(5, 5, 5, '裤子很有科技感，面料舒服', 5),
(6, 6, 6, '丝绒礼服很高级', 5),
(7, 7, 7, '泡泡袖尺码偏小，建议买大一码', 3),
(8, 8, 8, '皮夹克很帅气', 4),
(9, 9, 9, '卫衣很潮，原宿风', 5),
(10, 10, 10, '蜘蛛网蕾丝很有特色', 4),
(11, 11, 11, '刺绣上衣细节精致', 5),
(12, 12, 12, '铆钉裙很有朋克范', 4),
(13, 13, 13, '夹克面料厚实，适合秋冬', 5),
(14, 14, 14, '哥特靴子很酷', 5),
(15, 15, 15, '花边袜很可爱', 5),
(16, 16, 16, 'T恤印花清晰', 4),
(17, 17, 17, '项链搭配视觉系很合适', 5),
(18, 18, 18, '牛仔裤版型好', 4),
(19, 19, 19, '披风很有暗黑气质', 5),
(20, 20, 20, '运动鞋很轻便', 5);

-- 收藏数据
INSERT INTO favorites (user_id, product_id) VALUES
(1, 2), (1, 3), (2, 1), (2, 4), (3, 5), (3, 6), (4, 7), (4, 8), (5, 9), (5, 10),
(6, 11), (6, 12), (7, 13), (7, 14), (8, 15), (8, 16), (9, 17), (9, 18), (10, 19), (10, 20);

-- 购物车数据
INSERT INTO cart (user_id, product_id, quantity, created_at) VALUES
(1, 1, 2, NOW()), (1, 4, 1, NOW()), (2, 2, 1, NOW()), (2, 5, 3, NOW()),
(3, 3, 1, NOW()), (3, 6, 2, NOW()), (4, 7, 1, NOW()), (4, 8, 1, NOW()),
(5, 9, 2, NOW()), (5, 10, 1, NOW()), (6, 11, 1, NOW()), (6, 12, 2, NOW()),
(7, 13, 1, NOW()), (7, 14, 2, NOW()), (8, 15, 1, NOW()), (8, 16, 1, NOW()),
(9, 17, 1, NOW()), (9, 18, 1, NOW()), (10, 19, 2, NOW()), (10, 20, 1, NOW());

-- 物流数据
INSERT INTO logistics (order_id, tracking_number, company, status, updated_at) VALUES
(1,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '1', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已发货', NOW()),
(2,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '2', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(3,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '3', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '待揽收', NOW()),
(4,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '4', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已签收', NOW()),
(5,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '5', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(6,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '6', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已签收', NOW()),
(7,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '7', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(8,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '8', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已发货', NOW()),
(9,  CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '9', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(10, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '10', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已签收', NOW()),
(11, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '11', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(12, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '12', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已发货', NOW()),
(13, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '13', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(14, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '14', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已签收', NOW()),
(15, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '15', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(16, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '16', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已发货', NOW()),
(17, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '17', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(18, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '18', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已签收', NOW()),
(19, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '19', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '运输中', NOW()),
(20, CONCAT('SF', YEAR(NOW()), LPAD(MONTH(NOW()),2,'0'), LPAD(DAY(NOW()),2,'0'), '20', LPAD(FLOOR(RAND()*10000),4,'0')), '顺丰', '已发货', NOW());

-- 系统信息数据
INSERT INTO system_info (key_name, value) VALUES
('platform_email', 'support@infinate.com'),
('shipping_base', '18.00'),
('payment_gateway', 'WeChat,Alipay,UnionPay'),
('about_us', '无限饰穿搭商场，专注于暗黑与特别美学服饰'),
('service_tel', '400-123-4567'),
('address', '上海市徐汇区88号'),
('logistics_provider', '顺丰'),
('logistics_base_price', '18.00'),
('logistics_formula', 'base+distance*0.5+weight*2'),
('seo_keywords', '暗黑,哥特,朋克,洛丽塔,原宿,潮流'),
('seo_description', '中国暗黑潮流服饰电商平台');

-- 物流价格计算函数
DELIMITER //
CREATE FUNCTION calc_sf_price(distance_km INT, weight_kg DECIMAL(5,2))
RETURNS DECIMAL(10,2)
BEGIN
  DECLARE base DECIMAL(10,2) DEFAULT 18.00;
  RETURN base + distance_km * 0.5 + weight_kg * 2;
END//
DELIMITER ;

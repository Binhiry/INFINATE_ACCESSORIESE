// Frontend JavaScript Functions for INFINITÉ Accessories
class FrontendManager {
    constructor() {
        this.apiBase = 'http://localhost:3000/api';
        this.currentProducts = [];
        this.currentCategories = [];
        this.currentStyles = [];
        this.categoryAllProducts = [];
        this.categoryActiveStyle = '全部';
        this.newArrivalsPageSize = 9;
        this.newArrivalsCurrentPage = 1;
        this.cart = [];
        this.wishlist = [];
        // 优先从 infinite_user_profile（更完整）读；回退到 login_id；都没有就 '0'
        try {
          const profile = JSON.parse(localStorage.getItem('infinite_user_profile') || '{}');
          if (profile && (profile.user_id || profile.id)) {
            this.loginId = String(profile.user_id || profile.id);
          } else {
            this.loginId = localStorage.getItem('login_id') || '0';
          }
        } catch (e) {
          this.loginId = localStorage.getItem('login_id') || '0';
        }
        // 同步反方向：若 profile 有但 login_id 没有，写一次让前端共享
        if (this.loginId !== '0' && !localStorage.getItem('login_id')) {
          try { localStorage.setItem('login_id', this.loginId); } catch (e) {}
        }
        this.init();
    }

    init() {
        this.checkLoginStatus();
        this.setupEventListeners();
        this.loadCommonData();
        this.initCustomCursor();
        this.initScrollEffects();
    }

    checkLoginStatus() {
        if (this.loginId === '0') {
            // 静默跳转到登录页，不弹 alert 打扰用户
            window.location.href = 'login.html';
        }
    }

    setLoginId(id) {
        localStorage.setItem('login_id', String(id));
        this.loginId = id;
    }

    clearLoginId() {
        localStorage.setItem('login_id', '0');
        this.loginId = '0';
    }

    setupEventListeners() {
        // Navigation
        document.addEventListener('DOMContentLoaded', () => {
            this.setupNavigation();
            this.setupSearch();
            this.setupCart();
            this.setupWishlist();
        });

        // Page-specific initialization
        const currentPage = this.getCurrentPage();
        switch (currentPage) {
            case 'index':
                this.initHomepage();
                break;
            case 'categories':
                this.initCategoriesPage();
                break;
            case 'new-arrivals':
                this.initNewArrivalsPage();
                break;
            case 'brand-story':
                this.initBrandStoryPage();
                break;
            case 'inspiration':
                this.initInspirationPage();
                break;
            case 'membership':
                this.initMembershipPage();
                break;
        }
    }

    getCurrentPage() {
        const path = window.location.pathname;
        const page = path.split('/').pop().replace('.html', '');
        return page || 'index';
    }

    // Custom cursor
    initCustomCursor() {
        const cursor = document.getElementById('cursor');
        const cursorRing = document.getElementById('cursorRing');
        
        if (!cursor || !cursorRing) return;

        document.addEventListener('mousemove', (e) => {
            cursor.style.left = e.clientX + 'px';
            cursor.style.top = e.clientY + 'px';
            cursorRing.style.left = e.clientX + 'px';
            cursorRing.style.top = e.clientY + 'px';
        });

        document.addEventListener('mousedown', () => {
            cursor.style.transform = 'translate(-50%, -50%) scale(0.8)';
            cursorRing.style.transform = 'translate(-50%, -50%) scale(0.8)';
        });

        document.addEventListener('mouseup', () => {
            cursor.style.transform = 'translate(-50%, -50%) scale(1)';
            cursorRing.style.transform = 'translate(-50%, -50%) scale(1)';
        });
    }

    // Scroll effects
    initScrollEffects() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('reveal-active');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.reveal').forEach(el => {
            observer.observe(el);
        });
    }

    // Load common data
    async loadCommonData() {
        await Promise.all([
            this.loadCategories(),
            this.loadStyles(),
            this.loadCartFromStorage(),
            this.loadWishlistFromStorage()
        ]);
    }

    // Navigation setup
    setupNavigation() {
        const navLinks = document.querySelectorAll('header nav a');
        const currentPage = this.getCurrentPage();
        
        navLinks.forEach(link => {
            const href = link.getAttribute('href');
            if (href === `${currentPage}.html` || (currentPage === 'index' && href === 'index.html')) {
                link.classList.add('active');
            }
        });

        // Add smooth scroll to anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });
    }

    // Search functionality
    setupSearch() {
        const searchButtons = document.querySelectorAll('.icon-btn');
        searchButtons.forEach(btn => {
            if (btn.textContent === '🔍') {
                btn.addEventListener('click', () => this.showSearchModal());
            }
        });
    }

    showSearchModal() {
        const modal = document.createElement('div');
        modal.className = 'search-modal';
        modal.innerHTML = `
            <div class="search-backdrop"></div>
            <div class="search-content">
                <div class="search-header">
                    <h3>搜索商品</h3>
                    <button class="search-close">&times;</button>
                </div>
                <div class="search-form">
                    <input type="text" placeholder="输入商品名称、风格或关键词..." class="search-input">
                    <div class="search-filters">
                        <select class="search-category">
                            <option value="all">全部分类</option>
                        </select>
                        <select class="search-style">
                            <option value="all">全部风格</option>
                        </select>
                        <div class="price-range">
                            <input type="number" placeholder="最低价" class="price-min">
                            <span>-</span>
                            <input type="number" placeholder="最高价" class="price-max">
                        </div>
                    </div>
                    <button class="search-submit">搜索</button>
                </div>
                <div class="search-results"></div>
            </div>
        `;

        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .search-modal { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 10000; display: flex; align-items: center; justify-content: center; }
            .search-backdrop { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.8); backdrop-filter: blur(5px); }
            .search-content { position: relative; background: var(--deep); border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; padding: 32px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto; }
            .search-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
            .search-header h3 { color: var(--bone); font-family: 'Noto Serif SC', serif; font-size: 20px; letter-spacing: 0.1em; }
            .search-close { background: none; border: none; color: var(--silver); font-size: 24px; cursor: pointer; }
            .search-input { width: 100%; padding: 16px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); color: var(--bone); font-size: 16px; margin-bottom: 16px; outline: none; }
            .search-filters { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 20px; }
            .search-category, .search-style { padding: 12px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); color: var(--bone); outline: none; }
            .price-range { grid-column: 1/-1; display: flex; align-items: center; gap: 12px; }
            .price-min, .price-max { flex: 1; padding: 12px; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.1); color: var(--bone); outline: none; }
            .search-submit { width: 100%; padding: 16px; background: var(--blood); color: var(--lace); border: none; font-family: 'Noto Serif SC', serif; font-size: 14px; letter-spacing: 0.2em; cursor: pointer; transition: background 0.3s; }
            .search-submit:hover { background: var(--rose); }
            .search-results { margin-top: 24px; max-height: 300px; overflow-y: auto; }
        `;
        document.head.appendChild(style);

        document.body.appendChild(modal);

        // Populate filters
        this.populateSearchFilters(modal);

        // Event listeners
        const closeBtn = modal.querySelector('.search-close');
        const backdrop = modal.querySelector('.search-backdrop');
        const submitBtn = modal.querySelector('.search-submit');

        closeBtn.addEventListener('click', () => this.closeSearchModal(modal));
        backdrop.addEventListener('click', () => this.closeSearchModal(modal));
        submitBtn.addEventListener('click', () => this.performSearch(modal));

        const input = modal.querySelector('.search-input');
        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.performSearch(modal);
        });

        input.focus();
    }

    populateSearchFilters(modal) {
        const categorySelect = modal.querySelector('.search-category');
        const styleSelect = modal.querySelector('.search-style');

        this.currentCategories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.name;
            option.textContent = cat.name;
            categorySelect.appendChild(option);
        });

        this.currentStyles.forEach(style => {
            const option = document.createElement('option');
            option.value = style.name;
            option.textContent = style.name;
            styleSelect.appendChild(option);
        });
    }

    async performSearch(modal) {
        const query = modal.querySelector('.search-input').value;
        const category = modal.querySelector('.search-category').value;
        const style = modal.querySelector('.search-style').value;
        const minPrice = modal.querySelector('.price-min').value || null;
        const maxPrice = modal.querySelector('.price-max').value || null;

        if (!query.trim()) {
            this.showMessage('请输入搜索关键词', 'error');
            return;
        }

        try {
            const params = new URLSearchParams({
                q: query,
                category: category,
                style: style
            });

            if (minPrice) params.append('min_price', minPrice);
            if (maxPrice) params.append('max_price', maxPrice);

            const response = await fetch(`${this.apiBase}/search?${params}`);
            const result = await response.json();

            if (result.success) {
                this.displaySearchResults(modal, result.data);
            } else {
                this.showMessage('搜索失败：' + result.error, 'error');
            }
        } catch (error) {
            console.error('Search error:', error);
            this.showMessage('搜索失败，请重试', 'error');
        }
    }

    displaySearchResults(modal, products) {
        const resultsDiv = modal.querySelector('.search-results');
        
        if (products.length === 0) {
            resultsDiv.innerHTML = '<p style="text-align: center; color: var(--silver);">未找到相关商品</p>';
            return;
        }

        resultsDiv.innerHTML = `
            <h4 style="color: var(--bone); margin-bottom: 16px;">搜索结果 (${products.length})</h4>
            <div class="search-results-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
                ${products.map(product => this.createProductCard(product, 'small')).join('')}
            </div>
        `;

        // Add product card event listeners
        resultsDiv.querySelectorAll('.product-card, .product-card-small').forEach(card => {
            this.setupProductCardEvents(card);
        });
    }

    closeSearchModal(modal) {
        document.body.removeChild(modal);
    }

    // Cart functionality
    setupCart() {
        const cartButtons = document.querySelectorAll('.icon-btn');
        cartButtons.forEach(btn => {
            if (btn.textContent === '🛒') {
                btn.addEventListener('click', () => this.showCart());
            }
        });
    }

    loadCartFromStorage() {
        const savedCart = localStorage.getItem('infinite_cart');
        if (savedCart) {
            this.cart = JSON.parse(savedCart);
            this.updateCartUI();
        }
    }

    saveCartToStorage() {
        localStorage.setItem('infinite_cart', JSON.stringify(this.cart));
        this.updateCartUI();
    }

    addToCart(productId, quantity = 1) {
        const existingItem = this.cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += quantity;
        } else {
            this.cart.push({ id: productId, quantity });
        }
        
        this.saveCartToStorage();
        this.showMessage('已添加到购物车', 'success');
    }

    removeFromCart(productId) {
        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCartToStorage();
    }

    updateCartUI() {
        const cartButtons = document.querySelectorAll('.icon-btn');
        cartButtons.forEach(btn => {
            if (btn.textContent === '🛒') {
                const count = this.cart.reduce((sum, item) => sum + item.quantity, 0);
                btn.textContent = count > 0 ? `🛒(${count})` : '🛒';
            }
        });
    }

    showCart() {
        // Implementation for cart modal
        this.showMessage('购物车功能开发中', 'info');
    }

    // Wishlist functionality
    setupWishlist() {
        const wishlistButtons = document.querySelectorAll('.icon-btn');
        wishlistButtons.forEach(btn => {
            if (btn.textContent === '🤍') {
                btn.addEventListener('click', () => this.showWishlist());
            }
        });
    }

    loadWishlistFromStorage() {
        const savedWishlist = localStorage.getItem('infinite_wishlist');
        if (savedWishlist) {
            this.wishlist = JSON.parse(savedWishlist);
        }
    }

    saveWishlistToStorage() {
        localStorage.setItem('infinite_wishlist', JSON.stringify(this.wishlist));
    }

    toggleWishlist(productId) {
        const index = this.wishlist.indexOf(productId);
        
        if (index > -1) {
            this.wishlist.splice(index, 1);
            this.showMessage('已从收藏中移除', 'info');
        } else {
            this.wishlist.push(productId);
            this.showMessage('已添加到收藏', 'success');
        }
        
        this.saveWishlistToStorage();
    }

    showWishlist() {
        // Implementation for wishlist modal
        this.showMessage('收藏功能开发中', 'info');
    }

    // API calls
    async loadCategories() {
        try {
            const response = await fetch(`${this.apiBase}/categories`);
            const result = await response.json();
            
            if (result.success) {
                this.currentCategories = (result.data || []).map((cat) =>
                    typeof cat === 'string' ? { name: cat } : cat
                );
            }
        } catch (error) {
            console.error('Failed to load categories:', error);
        }
    }

    async loadStyles() {
        try {
            const response = await fetch(`${this.apiBase}/styles`);
            const result = await response.json();
            
            if (result.success) {
                this.currentStyles = result.data;
            }
        } catch (error) {
            console.error('Failed to load styles:', error);
        }
    }

    async loadProducts(category = null, style = null) {
        try {
            const params = new URLSearchParams();
            if (category) params.append('category', category);
            if (style) params.append('style', style);

            const response = await fetch(`${this.apiBase}/products?${params}`);
            const result = await response.json();
            
            if (result.success) {
                this.currentProducts = result.data;
                return result.data;
            }
        } catch (error) {
            console.error('Failed to load products:', error);
        }
        return [];
    }

    normalizeImageUrl(rawUrl, productId = null) {
        // 如果提供了商品ID，优先使用商品ID构建图片路径
        if (productId !== null && productId !== undefined && productId !== '') {
            const id = Number(productId);
            if (!isNaN(id) && id > 0) {
                return `pic/${id}.jpg`;
            }
        }

        const source = String(rawUrl || '').trim();
        if (!source) return '';
        if (/^(https?:|data:|blob:)/i.test(source)) {
            return source;
        }

        let path = source.replace(/\\/g, '/');
        if (path.startsWith('/')) {
            path = path.slice(1);
        }

        const picIndex = path.indexOf('pic/');
        if (picIndex >= 0) {
            return path.slice(picIndex);
        }

        if (/^[^/]+\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(path)) {
            return `pic/${path}`;
        }

        return path;
    }

    // Product card creation
    createProductCard(product, size = 'normal') {
        const isSmall = size === 'small';
        const cardClass = isSmall ? 'product-card-small' : 'product-card';
        const title = product.name || '未命名商品';
        const brand = product.brand || 'INFINITÉ';
        const category = product.category || product.style || '未分类';
        const description = (product.description || product.short_description || `${category}风格单品`).trim();
        const descText = description.length > (isSmall ? 34 : 56)
            ? `${description.slice(0, isSmall ? 34 : 56)}...`
            : description;
        const price = product.formatted_price || `¥ ${Number(product.price || 0).toFixed(2)}`;
        const image = this.normalizeImageUrl(product.image_url, product.id);
        
        return `
            <div class="${cardClass}" data-product-id="${product.id}">
                <div class="product-image" onclick="window.location.href='product_detail.html?id=${product.id}'">
                    ${image ? `<img src="${image}" alt="${title}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">` : ''}
                    <div class="product-image-fallback" style="display:${image ? 'none' : 'flex'}">🛍️</div>
                </div>
                <div class="product-info">
                    <p class="product-brand">${brand}</p>
                    <h3 class="product-name">${title}</h3>
                    <p class="product-category">分类：${category}</p>
                    <p class="product-desc">${descText}</p>
                    <div class="product-price">
                        <span class="current-price">${price}</span>
                    </div>
                </div>
            </div>
        `;
    }

    setupProductCardEvents(card) {
        // Add hover effects and other interactions
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-4px)';
        });

        card.addEventListener('mouseleave', () => {
            card.style.transform = 'translateY(0)';
        });
    }

    // Page-specific initializations
    async initHomepage() {
        try {
            const [featured, newArrivals, stats] = await Promise.all([
                fetch(`${this.apiBase}/featured?limit=8`).then(r => r.json()),
                fetch(`${this.apiBase}/new-arrivals?limit=8`).then(r => r.json()),
                fetch(`${this.apiBase}/stats`).then(r => r.json())
            ]);

            const featuredProducts = featured.success ? (featured.data || []) : [];
            const newArrivalProducts = newArrivals.success ? (newArrivals.data || []) : [];

            this.renderHeroFloatProducts(featuredProducts.length ? featuredProducts : newArrivalProducts);
            this.renderIndexProductGrid(newArrivalProducts.length ? newArrivalProducts : featuredProducts);
            this.setupHomepageCategoryCards();

            if (stats.success) {
                this.updateHomepageStats(stats.data);
            }
        } catch (error) {
            console.error('Failed to load homepage data:', error);
            this.setupHomepageCategoryCards();
        }
    }

    setupHomepageCategoryCards() {
        const cards = document.querySelectorAll('.cat-card[data-style]');
        if (!cards.length) return;

        cards.forEach((card) => {
            card.addEventListener('click', () => {
                const style = card.dataset.style;
                if (!style) return;

                card.classList.add('cat-card-clicked');
                setTimeout(() => {
                    window.location.href = `new-arrivals.html?style=${encodeURIComponent(style)}`;
                }, 160);
            });

            card.addEventListener('animationend', () => {
                card.classList.remove('cat-card-clicked');
            });
        });
    }

    renderHeroFloatProducts(products) {
        const container = document.querySelector('.hero-float');
        if (!container || !products || !products.length) return;

        const fallbackIcons = ['🦇', '🌹', '⛓️', '🌙'];
        const items = products.slice(0, 4);
        container.innerHTML = items.map((product, index) => {
            const cardClass = `fc-${(index % 4) + 1}`;
            const title = product.name || '未命名商品';
            const price = product.formatted_price || `¥ ${Number(product.price || 0).toFixed(2)}`;
            const image = this.normalizeImageUrl(product.image_url, product.id);
            return `
                <div class="float-card ${cardClass}" onclick="window.location.href='product_detail.html?id=${product.id}'">
                    <div class="float-card-img">
                        ${image ? `<img class="float-card-cover" src="${image}" alt="${title}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">` : ''}
                        <div class="float-card-fallback" style="display:${image ? 'none' : 'flex'}">${fallbackIcons[index % fallbackIcons.length]}</div>
                    </div>
                    <div class="float-card-label">
                        <div>${title}</div>
                        <div class="float-card-price">${price}</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    renderIndexProductGrid(products) {
        const grid = document.querySelector('.prod-grid');
        if (!grid || !products || !products.length) return;

        grid.innerHTML = products.slice(0, 8).map((product, index) => {
            const image = this.normalizeImageUrl(product.image_url, product.id);
            const title = product.name || '未命名商品';
            const brand = product.brand || 'INFINITÉ';
            const category = product.category || product.style || '未分类';
            const description = (product.description || product.short_description || `${category}风格单品`).trim();
            const descText = description.length > 42 ? `${description.slice(0, 42)}...` : description;
            const currentPrice = product.formatted_price || `¥ ${Number(product.price || 0).toFixed(2)}`;
            const fallbackIcons = ['🕸️', '🎀', '⛓️', '🌙', '🔮', '🌹', '🤖', '🎭'];

            return `
                <div class="prod-card" data-product-id="${product.id}">
                    <div class="prod-img" onclick="window.location.href='product_detail.html?id=${product.id}'">
                        ${image ? `<img class="prod-cover" src="${image}" alt="${title}" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">` : ''}
                        <div class="prod-img-inner ${image ? 'prod-fallback' : ''}" style="display:${image ? 'none' : 'flex'}">${fallbackIcons[index % fallbackIcons.length]}</div>
                    </div>
                    <div class="prod-info">
                        <div class="prod-name">${title}</div>
                        <div class="prod-category">分类：${category}</div>
                        <div class="prod-desc">${descText}</div>
                        <div class="prod-price">
                            <span class="price-now">${currentPrice}</span>
                        </div>
                        <div class="prod-brand">${brand}</div>
                    </div>
                </div>
            `;
        }).join('');

        grid.querySelectorAll('.prod-card').forEach((card, i) => {
            card.style.transitionDelay = `${i * 0.08}s`;
        });
    }

    renderHomepageProducts(products, section) {
        const container = document.querySelector(`.${section}-grid`);
        if (!container) return;

        container.innerHTML = products.map(product => this.createProductCard(product)).join('');
        
        container.querySelectorAll('.product-card').forEach(card => {
            this.setupProductCardEvents(card);
        });
    }

    updateHomepageStats(stats) {
        const statElements = document.querySelectorAll('.stat-number');
        if (statElements.length >= 4) {
            statElements[0].textContent = stats.total_products;
            statElements[1].textContent = stats.new_products;
            statElements[2].textContent = stats.monthly_orders;
            statElements[3].textContent = stats.total_users;
        }
    }

    async initCategoriesPage() {
        await this.loadCategories();
        await this.loadStyles();
        
        this.renderStyleGrid();
        this.setupCategoryFilters();

        await this.loadCategoryProductsPanel();
        this.setupCategoryProductFilterControls();
    }

    async loadCategoryProductsPanel() {
        const products = await this.loadProducts();
        this.categoryAllProducts = Array.isArray(products) ? products : [];
        this.categoryActiveStyle = '全部';
        this.renderCategoryStyleButtons();
        this.applyCategoryProductFilters();
    }

    setupCategoryProductFilterControls() {
        const nameInput = document.getElementById('filter-name');
        const minInput = document.getElementById('filter-min');
        const maxInput = document.getElementById('filter-max');

        [nameInput, minInput, maxInput].forEach((input) => {
            if (!input) return;
            input.addEventListener('input', () => this.applyCategoryProductFilters());
        });
    }

    renderCategoryStyleButtons() {
        const styleList = document.getElementById('filter-style-list');
        if (!styleList) return;

        const styleSet = new Set(
            this.categoryAllProducts
                .map((item) => item.style || item.category)
                .filter(Boolean)
        );
        const styles = ['全部', ...styleSet];

        styleList.innerHTML = styles.map((style) => `
            <button type="button" class="filter-style-btn${style === this.categoryActiveStyle ? ' active' : ''}" data-style="${style}">${style}</button>
        `).join('');

        styleList.querySelectorAll('.filter-style-btn').forEach((btn) => {
            btn.addEventListener('click', () => {
                this.categoryActiveStyle = btn.dataset.style || '全部';
                this.renderCategoryStyleButtons();
                this.applyCategoryProductFilters();
            });
        });
    }

    applyCategoryProductFilters() {
        const grid = document.getElementById('filter-prod-grid');
        if (!grid) return;

        const keyword = (document.getElementById('filter-name')?.value || '').trim();
        const minPrice = Number(document.getElementById('filter-min')?.value || 0);
        const maxRaw = Number(document.getElementById('filter-max')?.value || 0);
        const maxPrice = maxRaw > 0 ? maxRaw : Number.POSITIVE_INFINITY;

        const filtered = this.categoryAllProducts.filter((product) => {
            const style = product.style || product.category || '';
            const title = product.name || '';
            const price = Number(product.price || 0);

            const styleMatch = this.categoryActiveStyle === '全部' || style === this.categoryActiveStyle;
            const nameMatch = !keyword || title.includes(keyword);
            const priceMatch = price >= minPrice && price <= maxPrice;

            return styleMatch && nameMatch && priceMatch;
        });

        if (!filtered.length) {
            grid.innerHTML = '<div style="color:var(--silver);padding:40px;text-align:center;">暂无商品</div>';
            return;
        }

        grid.innerHTML = filtered.map((product) => this.createProductCard(product)).join('');
        grid.querySelectorAll('.product-card').forEach((card) => {
            this.setupProductCardEvents(card);
        });
    }

    renderStyleGrid() {
        const grid = document.querySelector('.style-grid');
        if (!grid) return;

        grid.innerHTML = this.currentStyles.map(style => `
            <div class="style-card" data-style="${style.name}">
                <div class="style-card-visual ${style.gradient}">${style.icon}</div>
                <div class="style-overlay"></div>
                <div class="style-card-info">
                    <div class="style-tags"><span class="style-tag">${style.tag}</span></div>
                    <div class="style-name">${style.name}</div>
                    <div class="style-cn">${style.name}</div>
                    <div class="style-meta">
                        <span class="style-count">${style.count} 件</span>
                        <span class="style-arrow">→</span>
                    </div>
                </div>
            </div>
        `).join('');

        // Add click handlers
        grid.querySelectorAll('.style-card').forEach(card => {
            card.addEventListener('click', () => {
                const style = card.dataset.style;
                this.filterByStyle(style);
            });
        });
    }

    setupCategoryFilters() {
        const filterChips = document.querySelectorAll('.filter-chip');
        filterChips.forEach(chip => {
            chip.addEventListener('click', () => {
                filterChips.forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                
                const filter = chip.textContent;
                this.filterStyles(filter);
            });
        });
    }

    filterStyles(filter) {
        const cards = document.querySelectorAll('.style-card');
        cards.forEach(card => {
            const style = card.dataset.style;
            const shouldShow = filter === '全部风格' || this.matchesFilter(style, filter);
            card.style.display = shouldShow ? 'block' : 'none';
        });
    }

    matchesFilter(style, filter) {
        const filterMap = {
            '暗系': ['哥特暗黑', 'Visual Kei', '暗潮'],
            '甜系': ['洛丽塔'],
            '街头系': ['朋克', '原宿'],
            '未来系': ['赛博朋克'],
            '复古系': ['蒸汽朋克'],
            '自然系': ['田园风']
        };
        
        const styles = filterMap[filter] || [];
        return styles.includes(style);
    }

    filterByStyle(style) {
        // Navigate to products page with style filter
        window.location.href = `new-arrivals.html?style=${encodeURIComponent(style)}`;
    }

    async initNewArrivalsPage() {
        const urlParams = new URLSearchParams(window.location.search);
        const style = urlParams.get('style');
        const categoriesRaw = urlParams.get('category');

        if (categoriesRaw && categoriesRaw.includes(',')) {
            // 多品类混搭，聚合所有相关商品
            const categoryList = categoriesRaw.split(',').map(c => c.trim()).filter(Boolean);
            let allProducts = [];
            for (const cat of categoryList) {
                const products = await this.loadProducts(cat, style);
                if (Array.isArray(products)) {
                    allProducts = allProducts.concat(products);
                }
            }
            // 去重（按 id）
            const seen = new Set();
            this.currentProducts = allProducts.filter(p => {
                if (seen.has(p.id)) return false;
                seen.add(p.id); return true;
            });
        } else {
            await this.loadProducts(categoriesRaw, style);
        }
        this.newArrivalsCurrentPage = 1;
        this.renderProductsGrid(1);
        this.setupSidebarFilters();
    }

    renderProductsGrid(page = this.newArrivalsCurrentPage) {
        const grid = document.querySelector('.prod-grid');
        if (!grid) return;

        const totalCount = this.currentProducts.length;
        const totalPages = Math.max(1, Math.ceil(totalCount / this.newArrivalsPageSize));
        const safePage = Math.min(Math.max(Number(page) || 1, 1), totalPages);
        this.newArrivalsCurrentPage = safePage;

        if (!totalCount) {
            grid.innerHTML = '<div style="color:var(--silver);padding:48px 0;text-align:center;grid-column:1/-1;">暂无符合条件的商品</div>';
            this.renderProductsPagination(0, 1, 1);

            const emptyCountElement = document.querySelector('.result-count em');
            if (emptyCountElement) {
                emptyCountElement.textContent = '0';
            }
            return;
        }

        const startIndex = (safePage - 1) * this.newArrivalsPageSize;
        const pageProducts = this.currentProducts.slice(startIndex, startIndex + this.newArrivalsPageSize);

        grid.innerHTML = pageProducts.map(product => this.createProductCard(product)).join('');
        
        grid.querySelectorAll('.product-card, .product-card-small').forEach(card => {
            this.setupProductCardEvents(card);
        });

        this.renderProductsPagination(totalCount, totalPages, safePage);

        // Update result count
        const countElement = document.querySelector('.result-count em');
        if (countElement) {
            countElement.textContent = totalCount;
        }
    }

    renderProductsPagination(totalCount, totalPages, currentPage) {
        const pagination = document.querySelector('.pagination');
        if (!pagination) return;

        if (!totalCount || totalPages <= 1) {
            pagination.style.display = 'none';
            pagination.innerHTML = '';
            return;
        }

        pagination.style.display = 'flex';

        const pageItems = this.getPageItems(totalPages, currentPage);
        const prevButton = `<button class="page-btn" data-page="${currentPage - 1}" ${currentPage === 1 ? 'disabled' : ''}>‹</button>`;
        const nextButton = `<button class="page-btn" data-page="${currentPage + 1}" ${currentPage === totalPages ? 'disabled' : ''}>›</button>`;

        const numberButtons = pageItems.map((item) => {
            if (item === '...') {
                return '<button class="page-btn" disabled>···</button>';
            }

            return `<button class="page-btn${item === currentPage ? ' active' : ''}" data-page="${item}">${item}</button>`;
        }).join('');

        pagination.innerHTML = `${prevButton}${numberButtons}${nextButton}`;

        pagination.querySelectorAll('.page-btn[data-page]').forEach((btn) => {
            btn.addEventListener('click', () => {
                const nextPage = Number(btn.dataset.page || 1);
                this.renderProductsGrid(nextPage);
                pagination.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            });
        });
    }

    getPageItems(totalPages, currentPage) {
        if (totalPages <= 7) {
            return Array.from({ length: totalPages }, (_, index) => index + 1);
        }

        const items = [1];
        const start = Math.max(2, currentPage - 1);
        const end = Math.min(totalPages - 1, currentPage + 1);

        if (start > 2) items.push('...');
        for (let i = start; i <= end; i += 1) {
            items.push(i);
        }
        if (end < totalPages - 1) items.push('...');

        items.push(totalPages);
        return items;
    }

    setupSidebarFilters() {
        const checkboxes = document.querySelectorAll('.sidebar-check');
        const priceInputs = document.querySelectorAll('.price-input');

        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', () => this.applyFilters());
        });

        priceInputs.forEach(input => {
            input.addEventListener('input', () => this.applyFilters());
        });
    }

    async applyFilters() {
        const checkedStyles = Array.from(document.querySelectorAll('.sidebar-check:checked'))
            .map(cb => cb.nextElementSibling.textContent);
        
        const minPrice = document.querySelector('.price-input:first-of-type')?.value || null;
        const maxPrice = document.querySelector('.price-input:last-of-type')?.value || null;

        const products = await this.loadProducts();
        
        const filtered = products.filter(product => {
            const styleMatch = checkedStyles.length === 0 || checkedStyles.includes('全部风格') || checkedStyles.includes(product.style);
            const priceMatch = (!minPrice || product.price >= minPrice) && (!maxPrice || product.price <= maxPrice);
            return styleMatch && priceMatch;
        });

        this.currentProducts = filtered;
        this.newArrivalsCurrentPage = 1;
        this.renderProductsGrid(1);
    }

    initBrandStoryPage() {
        // Add scroll animations for brand story
        this.setupStoryAnimations();
    }

    setupStoryAnimations() {
        const observerOptions = {
            threshold: 0.2,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('animate-in');
                }
            });
        }, observerOptions);

        document.querySelectorAll('.story-section').forEach(section => {
            observer.observe(section);
        });
    }

    initInspirationPage() {
        // Setup inspiration gallery
        this.setupInspirationGallery();
    }

    setupInspirationGallery() {
        // Implementation for inspiration gallery
        console.log('Inspiration page initialized');
    }

    initMembershipPage() {
        // Setup membership features
        this.setupMembershipFeatures();
    }

    setupMembershipFeatures() {
        // Implementation for membership features
        console.log('Membership page initialized');
    }

    // Utility functions
    showMessage(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = 'toast-message';
        toast.textContent = message;
        
        const colors = {
            success: 'var(--green)',
            error: 'var(--rose)',
            info: 'var(--blue)'
        };
        
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            background: ${colors[type] || colors.info};
            color: white;
            border-radius: 4px;
            font-size: 12px;
            z-index: 10000;
            opacity: 0;
            transition: opacity 0.3s;
            font-family: 'Noto Sans SC', sans-serif;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => toast.style.opacity = '1', 100);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    }
}

// Initialize frontend manager
let frontendManager;
document.addEventListener('DOMContentLoaded', () => {
    frontendManager = new FrontendManager();
});

// Export for global access
window.frontendManager = frontendManager;

const LOGIN_ID_KEY = 'login_id';
const USER_PROFILE_KEY = 'infinite_user_profile';

// 统一从多个 key 读出当前登录 id：login_id / infinite_user_profile.user_id 都能识别
function getCurrentLoginId() {
  try {
    const direct = localStorage.getItem(LOGIN_ID_KEY);
    if (direct && direct !== '0' && direct !== 'null' && direct !== 'undefined' && direct !== '') return direct;
  } catch (e) {}
  try {
    const profile = JSON.parse(localStorage.getItem(USER_PROFILE_KEY) || '{}');
    const id = profile && (profile.user_id || profile.id);
    if (id) return String(id);
  } catch (e) {}
  return '0';
}

function checkLoginStatus() {
  const loginId = getCurrentLoginId();
  if (loginId === '0' || loginId === 'null') {
    // 静默跳转到登录页，不弹 alert 打扰用户
    window.location.href = 'login.html';
  } else {
    // 反向同步：若 login_id 没有但 profile 有，写一次保证后续页面读到
    try {
      if (!localStorage.getItem(LOGIN_ID_KEY)) {
        localStorage.setItem(LOGIN_ID_KEY, loginId);
      }
    } catch (e) {}
  }
}

function setLoginId(id) {
  localStorage.setItem(LOGIN_ID_KEY, String(id));
}

function clearLoginId() {
  localStorage.setItem(LOGIN_ID_KEY, '0');
}

document.querySelector('.icon-btn[title="我的账户"]').addEventListener('click', function() {
  const loginId = getCurrentLoginId();
  if (loginId === '0' || loginId === 'null') {
    // 静默跳转到登录页，不弹 alert
    window.location.href = 'login.html';
  } else {
    window.location.href = 'user_center.html';
  }
});

// ============================================================
// 跨页面登录状态同步：当其他页面/标签登录或退出后，广播事件让当前页面同步
// ============================================================
(function setupCrossPageLoginSync() {
  // 同步函数：每次打开新页面时，将 login_id 与 infinite_user_profile 双向对齐
  function alignLoginState() {
    try {
      const direct = localStorage.getItem(LOGIN_ID_KEY);
      let profile = {};
      try { profile = JSON.parse(localStorage.getItem(USER_PROFILE_KEY) || '{}'); } catch (e) {}
      const profileId = profile && (profile.user_id || profile.id);

      // 1) profile 有 id 但 login_id 没有 → 写入 login_id
      if (profileId && (!direct || direct === '0' || direct === '')) {
        localStorage.setItem(LOGIN_ID_KEY, String(profileId));
      }
      // 2) login_id 有但 profile 没有对应 username → 从后端补全
      if (direct && direct !== '0' && !profile.username) {
        // 异步拉一次用户信息（失败不影响主流程）
        try {
          fetch(`${API_BASE || ''}/users?user_id=${encodeURIComponent(direct)}`)
            .then(r => r.ok ? r.json() : null)
            .then(data => {
              if (data && data.success && data.data && data.data[0]) {
                const u = data.data[0];
                localStorage.setItem(USER_PROFILE_KEY, JSON.stringify({
                  ...profile,
                  user_id: u.user_id || u.id,
                  username: u.username,
                  email: u.email || '',
                  phone: u.phone || '',
                  address: u.address || '',
                  level: u.member_level || '普通',
                  points: u.points || 0,
                  avatar: profile.avatar || '👤'
                }));
              }
            })
            .catch(() => {});
        } catch (e) {}
      }
    } catch (e) {}
  }
  // 立刻执行一次
  alignLoginState();

  // 监听其它标签页的 storage 事件
  window.addEventListener('storage', function(ev) {
    if (ev.key === LOGIN_ID_KEY || ev.key === USER_PROFILE_KEY || ev.key === 'role') {
      alignLoginState();
    }
  });
})();

// ============================================================
// 页眉用户头像智能渲染：自动处理所有带 #header-user-avatar 的元素
// 优先显示真实头像（infinite_user_profile.avatar_url / avatar 文件），未登录则显示 👤
// ============================================================
(function loadHeaderAvatars() {
  function resolve() {
    // 已登录 profile 优先
    let profile = {};
    try { profile = JSON.parse(localStorage.getItem(USER_PROFILE_KEY) || '{}'); } catch (e) {}
    // 兜底从 login_id 推导用户 ID
    const loginId = localStorage.getItem(LOGIN_ID_KEY);
    const userId = profile.user_id || profile.id || (loginId && loginId !== '0' ? loginId : '');
    // 头像 URL：优先 profile.avatar_url，否则从 login_id 推导
    const derivedUrl = userId ? `/avatar/${userId}.jpg` : '';
    return {
      avatarUrl: profile.avatar_url || derivedUrl,
      avatar: profile.avatar || '',
      userId: userId,
      username: profile.username || ''
    };
  }
  function apply() {
    const info = resolve();
    const els = document.querySelectorAll('#header-user-avatar, .header-avatar-link');
    if (!els.length) return;
    els.forEach(el => {
      // 清空现有内容
      el.innerHTML = '';
      el.style.cssText = (el.style.cssText || '') + '; display:inline-flex; align-items:center; justify-content:center; text-decoration:none;';
      // 1) 优先：用户上传的头像（infinite_user_profile.avatar_url）
      if (info.avatarUrl) {
        const img = document.createElement('img');
        img.src = info.avatarUrl;
        img.alt = info.username || '用户';
        img.style.cssText = 'width:32px;height:32px;border-radius:50%;object-fit:cover;border:1px solid rgba(201,168,76,0.4);';
        img.onerror = function() { tryFallback(el, info); };
        el.appendChild(img);
        return;
      }
      tryFallback(el, info);
    });
  }
  function tryFallback(el, info) {
    el.innerHTML = '';
    // 2) 次优：当前 user_id 对应的真实头像文件
    if (info.userId) {
      const img = document.createElement('img');
      img.src = `/avatar/${info.userId}.jpg`;
      img.alt = info.username || '用户';
      img.style.cssText = 'width:32px;height:32px;border-radius:50%;object-fit:cover;border:1px solid rgba(201,168,76,0.4);';
      img.onerror = function() { useInitial(el, info); };
      el.appendChild(img);
      return;
    }
    useInitial(el, info);
  }
  function useInitial(el, info) {
    el.innerHTML = '';
    // 3) 兜底：用户名首字符
    const initial = (info.username && info.username.length > 0) ? info.username.charAt(0).toUpperCase() : 'U';
    const span = document.createElement('span');
    span.className = 'user-avatar-header';
    span.textContent = initial;
    span.style.cssText = 'font-size:20px; line-height:1; display:inline-block;';
    el.appendChild(span);
  }
  // 立即执行一次
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', apply);
  } else {
    apply();
  }
  // 登录状态变化时重渲染
  window.addEventListener('storage', function(ev) {
    if (ev.key === LOGIN_ID_KEY || ev.key === USER_PROFILE_KEY) apply();
  });
})();

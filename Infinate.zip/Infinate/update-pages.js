// Simple script to update HTML files with frontend JavaScript include
const fs = require('fs');
const path = require('path');

const filesToUpdate = [
    'inspiration.html',
    'membership.html'
];

filesToUpdate.forEach(file => {
    const filePath = path.join(__dirname, file);
    
    try {
        let content = fs.readFileSync(filePath, 'utf8');
        
        // Add frontend.js include before closing body tag
        if (content.includes('</body>') && !content.includes('frontend-functions.js')) {
            content = content.replace('</body>', '<script src="frontend-functions.js"></script>\n</body>');
            
            fs.writeFileSync(filePath, content, 'utf8');
            console.log(`Updated ${file} successfully`);
        } else {
            console.log(`Skipped ${file} - already updated or no </body> tag found`);
        }
    } catch (error) {
        console.error(`Error updating ${file}:`, error.message);
    }
});

console.log('Page update process completed.');
